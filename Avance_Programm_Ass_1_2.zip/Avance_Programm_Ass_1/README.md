# UniBites – Campus Canteen Hub

A phone-friendly campus canteen web app where students can browse the daily menu, search and filter meals, customise items with add-ons, and build an order tray with a live cart and promo codes.

The project exists in **two versions**:

| Version | Tech | Entry file | Status |
|---|---|---|---|
| **Legacy (vanilla)** | HTML, CSS, JavaScript | `legacy_index.html` | Complete, runs directly in the browser |
| **React** | React 19, Vite, React Router, Lucide icons | `index.html` | Complete, colorful theme included (`npm install` then `npm run dev`) |

---

## Features

- **Live menu** with 10+ items across categories: burgers, mains, pizza, bowls, breakfast, beverages, snacks and desserts
- **Search** by meal name with a clear button
- **Category tabs** with item counts
- **Dietary filters** (e.g. halal) and badges for budget, spicy and chef-special meals
- **Sorting** by recommended, price (low to high / high to low) and rating
- **Grid and list view** toggle
- **Item details** on each card: price, discount price, rating, reviews, calories, protein, prep time and allergens
- **Add-ons / customisation** per item (e.g. extra cheese, double patty)
- **Favourites** list with a heart counter
- **Cart drawer** with quantity controls, remove item, clear tray, subtotal and final total
- **Order type** selection: Pickup or Dine-in
- **Promo codes** with instant discount
- **Light / dark theme** toggle (legacy version)
- **Persistent data**: cart and favourites are saved in the browser's `localStorage`, so they survive a page refresh
- **Toast notifications** for actions such as adding an item or applying a code
- **Responsive design** for phones, tablets and desktops

### Promo codes

| Version | Code | Discount |
|---|---|---|
| Both | `STUDENT15` | 15% off |
| Legacy | `CAMPUSFIRST` | $2.00 off |
| Legacy | `FREESHAKE` | $1.50 off |
| React | `CAMPUS10` or `FREESHIP` | 10% off |

---

## Project Structure

```
Avance_Programm_Ass_1/
├── legacy_index.html      # Vanilla version – open this file to run the app
├── script.js              # Vanilla version logic (same content as legacy_script.js)
├── styles.css             # Vanilla version styles (same content as legacy_styles.css)
├── legacy_script.js       # Backup copy of the vanilla JavaScript
├── legacy_styles.css      # Backup copy of the vanilla CSS
├── assets/                # Meal images used by the vanilla version
│
├── index.html             # Vite / React entry page
├── package.json           # Dependencies and npm scripts
├── package-lock.json
├── vite.config.js         # Vite config (dev server on port 3000)
├── public/
│   ├── menu.json          # Menu data used by the React version
│   ├── favicon.svg        # Site icon
│   └── assets/            # Meal photos + illustrated SVGs (pancakes, brownie, mozzarella, matcha)
└── src/
    ├── components/
    │   ├── Header.jsx     # Top bar, logo, navigation, cart and favourites buttons
    │   ├── MenuList.jsx   # Menu grid, sorting, empty and error states
    │   ├── ItemCard.jsx   # Single meal card
    │   └── Cart.jsx       # Cart page / tray with promo code input
    ├── context/
    │   └── CartContext.jsx  # Global state: cart, favourites, promo codes, totals, toasts
    ├── main.jsx           # React entry point (loads index.css)
    ├── App.jsx            # Routes, header, toast and footer
    ├── index.css          # Colorful theme for the whole React app
    └── pages/
        ├── MenuPage.jsx   # Menu page with search, tabs and filters
        └── ItemPage.jsx   # Dish details with add-ons, quantity and notes
```

---

## How to Run

### Option 1: Vanilla version (no installation needed)

1. Unzip the project.
2. Double-click **`legacy_index.html`** to open it in any modern browser.

An internet connection is only needed to load the Google Fonts (Outfit and Plus Jakarta Sans). Everything else works offline.

### Option 2: React version

**Requirements:** [Node.js](https://nodejs.org/) (version 18 or newer) and npm.

```bash
# 1. Go into the project folder
cd Avance_Programm_Ass_1

# 2. Install dependencies (this recreates the node_modules folder)
npm install

# 3. Start the development server
npm run dev
```

Then open **http://localhost:3000** in your browser.

Other scripts:

| Command | What it does |
|---|---|
| `npm run dev` | Starts the Vite dev server with hot reload |
| `npm run build` | Creates an optimised production build in `dist/` |
| `npm run preview` | Serves the production build locally |

> The `node_modules` folder is not included in the submission zip to keep the file size small. Running `npm install` brings it back.

---

## Technologies Used

- **HTML5, CSS3, JavaScript (ES6+)** – vanilla version
- **React 19** – component-based UI
- **React Router DOM 7** – page navigation
- **React Context API** – shared cart and favourites state
- **Vite** – fast development server and build tool
- **Lucide React** – icon set
- **Google Fonts** – Outfit and Plus Jakarta Sans
- **localStorage** – saving cart and favourites in the browser

---

## Project Status

- The **vanilla version is complete and fully working.**
- The **React version is complete too**: entry file (`src/main.jsx`), root `App.jsx` with routes (`/`, `/cart`, `/item/:id`), the item details page (`src/pages/ItemPage.jsx`) and the colorful stylesheet (`src/index.css`) are all included.

---

## Notes

- Prices are shown in dollars.
- Menu data in the vanilla version is stored inside `script.js`; the React version reads it from `public/menu.json`.
- This is a front-end only project: there is no backend, so orders are not actually sent anywhere.
