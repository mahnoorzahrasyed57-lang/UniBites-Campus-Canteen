import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { Heart, Plus, Check, Star, Flame, Clock } from 'lucide-react';

export default function ItemCard({ item }) {
  const { addToCart, toggleFavorite, isFavorite } = useCart();
  const [isAdding, setIsAdding] = useState(false);
  const navigate = useNavigate();

  const fav = isFavorite(item.id);
  const discountPct =
    item.originalPrice && item.originalPrice > item.price
      ? Math.round((1 - item.price / item.originalPrice) * 100)
      : 0;

  const handleQuickAdd = (e) => {
    e.stopPropagation();
    e.preventDefault();
    setIsAdding(true);
    addToCart(item, 1, [], '');

    setTimeout(() => {
      setIsAdding(false);
    }, 900);
  };

  const handleFavToggle = (e) => {
    e.stopPropagation();
    e.preventDefault();
    toggleFavorite(item.id);
  };

  return (
    <article
      className="item-card"
      onClick={() => navigate(`/item/${item.id}`)}
      tabIndex={0}
      role="button"
      onKeyDown={(e) => {
        if (e.key === 'Enter') navigate(`/item/${item.id}`);
      }}
      aria-label={`View details for ${item.name}`}
    >
      {/* Card Media Header */}
      <div className="card-media-wrap">
        <img
          src={item.image}
          alt={item.name}
          className="card-img"
          loading="lazy"
          onError={(e) => {
            e.target.src = '/assets/burger.jpg'; // graceful fallback
          }}
        />

        {/* Top Badges */}
        <div className="card-top-badges">
          {item.badge && <span className="card-badge-highlight">{item.badge}</span>}
          {item.isSpicy && (
            <span className="card-badge-spicy" title="Spicy Dish">
              <Flame size={12} /> Spicy
            </span>
          )}
        </div>

        {discountPct > 0 && <span className="card-discount">-{discountPct}% OFF</span>}

        {/* Favorite Floating Button */}
        <button
          type="button"
          className={`card-fav-btn ${fav ? 'favorited' : ''}`}
          onClick={handleFavToggle}
          aria-label={fav ? `Remove ${item.name} from favorites` : `Save ${item.name} to favorites`}
          title={fav ? 'Favorited' : 'Save as Favorite'}
        >
          <Heart size={18} fill={fav ? '#ef4444' : 'none'} stroke={fav ? '#ef4444' : '#475569'} />
        </button>
      </div>

      {/* Card Body */}
      <div className="card-body">
        {/* Category & Rating */}
        <div className="card-meta-row">
          <span className="card-category">{item.category}</span>
          <div className="card-rating" aria-label={`Rating ${item.rating} out of 5 stars`}>
            <Star size={14} className="star-icon" fill="#f59e0b" stroke="#f59e0b" />
            <span className="rating-num">{item.rating}</span>
            <span className="rating-count">({item.reviews})</span>
          </div>
        </div>

        {/* Item Title */}
        <h3 className="card-title">
          <Link
            to={`/item/${item.id}`}
            onClick={(e) => e.stopPropagation()}
            className="card-title-link"
          >
            {item.name}
          </Link>
        </h3>

        {/* Truncated Description */}
        <p className="card-desc">{item.description}</p>

        {/* Nutritional & Prep Chips */}
        <div className="card-chips">
          <span className="chip-item">
            <Clock size={12} /> {item.prepTime}
          </span>
          <span className="chip-item">{item.calories} kcal</span>
          {item.dietary?.map((diet) => (
            <span key={diet} className={`chip-diet chip-${diet}`}>
              {diet}
            </span>
          ))}
        </div>

        {/* Card Footer: Price & Quick Action */}
        <div className="card-footer">
          <div className="price-wrap">
            <span className="price-current">${Number(item.price).toFixed(2)}</span>
            {item.originalPrice && (
              <span className="price-original">${Number(item.originalPrice).toFixed(2)}</span>
            )}
          </div>

          <div className="card-actions">
            <button
              type="button"
              className={`btn-quick-add ${isAdding ? 'btn-added' : ''}`}
              onClick={handleQuickAdd}
              aria-label={`Add ${item.name} to cart`}
              title="Add to tray"
            >
              {isAdding ? (
                <>
                  <Check size={16} />
                  <span>Added</span>
                </>
              ) : (
                <>
                  <Plus size={16} />
                  <span>Add</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}
