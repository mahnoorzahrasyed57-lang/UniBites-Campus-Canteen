import React, { useState } from 'react';
import ItemCard from './ItemCard';
import { ArrowUpDown, SearchX, RefreshCw, AlertCircle } from 'lucide-react';

export default function MenuList({
  items,
  isLoading,
  error,
  onRetry,
  onClearFilters,
  searchQuery,
  selectedCategory,
  showFavoritesOnly
}) {
  const [sortBy, setSortBy] = useState('featured'); // 'featured', 'price-asc', 'price-desc', 'calories', 'rating'

  // Apply sorting
  const sortedItems = [...items].sort((a, b) => {
    if (sortBy === 'price-asc') return a.price - b.price;
    if (sortBy === 'price-desc') return b.price - a.price;
    if (sortBy === 'calories') return a.calories - b.calories;
    if (sortBy === 'rating') return b.rating - a.rating;
    return 0; // default featured order from JSON
  });

  // Render loading skeleton
  if (isLoading) {
    return (
      <section className="menu-list-section" aria-busy="true" aria-label="Loading menu">
        <div className="section-header-row">
          <div className="skeleton-bar" style={{ width: '180px', height: '24px' }}></div>
          <div className="skeleton-bar" style={{ width: '120px', height: '36px' }}></div>
        </div>
        <div className="menu-grid">
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div key={n} className="skeleton-card">
              <div className="skeleton-img"></div>
              <div className="skeleton-content">
                <div className="skeleton-bar" style={{ width: '40%', height: '14px' }}></div>
                <div className="skeleton-bar" style={{ width: '85%', height: '20px' }}></div>
                <div className="skeleton-bar" style={{ width: '100%', height: '36px' }}></div>
                <div className="skeleton-footer">
                  <div className="skeleton-bar" style={{ width: '30%', height: '22px' }}></div>
                  <div className="skeleton-bar" style={{ width: '35%', height: '36px', borderRadius: '20px' }}></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    );
  }

  // Render error message
  if (error) {
    return (
      <section className="menu-error-box" role="alert">
        <AlertCircle size={44} className="error-icon" />
        <h3 className="error-title">Couldn't load today's menu</h3>
        <p className="error-desc">{error}</p>
        {onRetry && (
          <button type="button" className="btn-retry" onClick={onRetry}>
            <RefreshCw size={16} />
            <span>Try Again</span>
          </button>
        )}
      </section>
    );
  }

  // Render empty state
  if (sortedItems.length === 0) {
    return (
      <section className="empty-results-box" aria-label="No dishes found">
        <SearchX size={54} className="empty-icon" />
        <h3 className="empty-title">No dishes found</h3>
        <p className="empty-desc">
          {showFavoritesOnly
            ? "You haven't added any favorite dishes yet. Click the heart icon on any dish to bookmark it!"
            : searchQuery
            ? `We couldn't find anything matching "${searchQuery}". Try another keyword or check different categories.`
            : 'No dishes are available in this category today.'}
        </p>
        {onClearFilters && (
          <button type="button" className="btn-clear-filters" onClick={onClearFilters}>
            Reset All Filters
          </button>
        )}
      </section>
    );
  }

  return (
    <section className="menu-list-section" aria-label="Menu Items">
      {/* Top Header of the Menu List */}
      <div className="section-header-row">
        <div className="count-label">
          Showing <strong>{sortedItems.length}</strong> {sortedItems.length === 1 ? 'dish' : 'dishes'}
          {showFavoritesOnly && ' in Favorites'}
          {selectedCategory !== 'all' && ` • ${selectedCategory.toUpperCase()}`}
        </div>

        {/* Sort Select */}
        <div className="sort-control">
          <ArrowUpDown size={15} className="sort-icon" />
          <label htmlFor="sort-dropdown" className="sr-only">
            Sort dishes by
          </label>
          <select
            id="sort-dropdown"
            className="sort-dropdown"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
          >
            <option value="featured">Featured / Chef Pick</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="rating">Highest Rated</option>
            <option value="calories">Lowest Calories</option>
          </select>
        </div>
      </div>

      {/* Responsive Grid */}
      <div className="menu-grid">
        {sortedItems.map((item) => (
          <ItemCard key={item.id} item={item} />
        ))}
      </div>
    </section>
  );
}
