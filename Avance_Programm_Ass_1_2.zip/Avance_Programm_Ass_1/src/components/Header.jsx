import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { Utensils, ShoppingBag, Heart, Clock, Sparkles } from 'lucide-react';

export default function Header({ showFavoritesOnly, setShowFavoritesOnly }) {
  const { totalCount, finalTotal, favorites } = useCart();

  return (
    <>
      {/* Top Campus Alert Bar */}
      <aside className="top-banner" aria-label="Campus Notice">
        <div className="container top-banner-inner">
          <div className="banner-left">
            <span className="live-status-dot" aria-hidden="true"></span>
            <span className="live-status-text">Canteen Open & Cooking</span>
            <span className="banner-separator">•</span>
            <span className="banner-hours">
              <Clock size={13} style={{ display: 'inline', verticalAlign: '-1px', marginRight: '4px' }} />
              Avg Prep: <strong>6-8 mins</strong>
            </span>
          </div>
          <div className="banner-right">
            <span className="promo-tag">
              <Sparkles size={12} style={{ display: 'inline', verticalAlign: '-1px', marginRight: '4px' }} />
              Use code <strong>STUDENT15</strong> for 15% OFF
            </span>
          </div>
        </div>
      </aside>

      {/* Main Navigation Header */}
      <header className="main-navbar" id="top-navbar">
        <div className="container navbar-inner">
          {/* Logo */}
          <Link to="/" className="brand-logo" aria-label="Campus Canteen Home">
            <div className="brand-icon-box">
              <Utensils size={22} className="brand-icon" />
            </div>
            <div className="brand-info">
              <h1 className="brand-title">UniBites<span className="brand-accent">.</span></h1>
              <p className="brand-subtitle">Campus Dining • Hall L1</p>
            </div>
          </Link>

          {/* Desktop & Tablet Navigation */}
          <nav className="desktop-nav" aria-label="Main Navigation">
            <NavLink
              to="/"
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
              end
            >
              Today's Menu
            </NavLink>

            {/* Quick Favorites Filter Button */}
            {setShowFavoritesOnly && (
              <button
                type="button"
                className={`nav-fav-btn ${showFavoritesOnly ? 'active' : ''}`}
                onClick={() => setShowFavoritesOnly((prev) => !prev)}
                title="Filter favorited items"
                aria-pressed={showFavoritesOnly}
              >
                <Heart size={18} className={showFavoritesOnly ? 'fill-current' : ''} />
                <span>Favorites</span>
                <span className={`pill-counter ${favorites.length > 0 ? 'has-items' : ''}`}>
                  {favorites.length}
                </span>
              </button>
            )}

            {/* Cart Link Button with Badge */}
            <NavLink
              to="/cart"
              className={({ isActive }) => `header-cart-btn ${isActive ? 'active' : ''}`}
              aria-label={`View Cart, ${totalCount} items`}
            >
              <div className="cart-btn-icon-wrap">
                <ShoppingBag size={20} />
                {totalCount > 0 && (
                  <span className="cart-badge-counter animate-pop">
                    {totalCount > 99 ? '99+' : totalCount}
                  </span>
                )}
              </div>
              <div className="cart-btn-text">
                <span className="cart-btn-label">My Tray</span>
                <span className="cart-btn-total">${finalTotal.toFixed(2)}</span>
              </div>
            </NavLink>
          </nav>
        </div>
      </header>

      {/* Phone-friendly Sticky Bottom Navigation Bar (Visible on mobile screens) */}
      <nav className="mobile-bottom-nav" aria-label="Mobile Navigation">
        <NavLink
          to="/"
          className={({ isActive }) => `mobile-nav-item ${isActive && !showFavoritesOnly ? 'active' : ''}`}
          onClick={() => setShowFavoritesOnly && setShowFavoritesOnly(false)}
        >
          <Utensils size={20} />
          <span>Menu</span>
        </NavLink>

        {setShowFavoritesOnly && (
          <button
            type="button"
            className={`mobile-nav-item ${showFavoritesOnly ? 'active' : ''}`}
            onClick={() => setShowFavoritesOnly((prev) => !prev)}
            aria-label="Toggle favorites filter"
          >
            <div className="mobile-icon-badge-wrap">
              <Heart size={20} className={showFavoritesOnly ? 'fill-current' : ''} />
              {favorites.length > 0 && (
                <span className="mobile-badge">{favorites.length}</span>
              )}
            </div>
            <span>Favorites</span>
          </button>
        )}

        <NavLink
          to="/cart"
          className={({ isActive }) => `mobile-nav-item ${isActive ? 'active' : ''}`}
          aria-label={`Cart with ${totalCount} items`}
        >
          <div className="mobile-icon-badge-wrap">
            <ShoppingBag size={20} />
            {totalCount > 0 && (
              <span className="mobile-badge cart-count-pulse">{totalCount}</span>
            )}
          </div>
          <span>Tray (${finalTotal.toFixed(2)})</span>
        </NavLink>
      </nav>
    </>
  );
}
