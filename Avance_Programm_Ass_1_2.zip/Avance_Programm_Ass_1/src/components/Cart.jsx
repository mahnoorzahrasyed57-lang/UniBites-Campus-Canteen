import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import {
  ShoppingBag,
  Plus,
  Minus,
  Trash2,
  Tag,
  ArrowRight,
  CheckCircle2,
  Clock,
  Sparkles,
  ChevronLeft
} from 'lucide-react';

export default function Cart({ allowCheckout = true }) {
  const {
    cartItems,
    totalCount,
    cartSubtotal,
    discountPercent,
    discountAmount,
    finalTotal,
    promoCode,
    promoMessage,
    updateQuantity,
    removeFromCart,
    clearCart,
    applyPromo
  } = useCart();

  const [inputCode, setInputCode] = useState('');
  const [orderNotes, setOrderNotes] = useState('');
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [orderConfirmed, setOrderConfirmed] = useState(null);

  const handleApplyPromo = (e) => {
    e.preventDefault();
    applyPromo(inputCode);
  };

  const handlePlaceOrder = () => {
    setIsCheckingOut(true);
    setTimeout(() => {
      const orderId = `UB-${Math.floor(1000 + Math.random() * 9000)}`;
      setOrderConfirmed({
        id: orderId,
        itemsCount: totalCount,
        totalPaid: finalTotal,
        prepMins: Math.floor(6 + Math.random() * 5),
        pickupCounter: 'Express Pickup Window 2'
      });
      setIsCheckingOut(false);
    }, 1200);
  };

  const handleDoneOrder = () => {
    setOrderConfirmed(null);
    clearCart();
  };

  // Render empty cart state
  if (cartItems.length === 0 && !orderConfirmed) {
    return (
      <div className="cart-empty-container">
        <div className="empty-cart-card">
          <div className="empty-cart-icon-wrap">
            <ShoppingBag size={48} className="empty-cart-icon" />
          </div>
          <h2 className="empty-cart-title">Your Order Tray is Empty</h2>
          <p className="empty-cart-desc">
            Looks like you haven't picked your meal yet. Explore today's freshly prepared specials, burgers, bowls, and coffees!
          </p>
          <Link to="/" className="btn-browse-menu">
            <ChevronLeft size={18} />
            <span>Browse Today's Menu</span>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="cart-wrapper">
      {/* Order Placed Confirmation Modal */}
      {orderConfirmed && (
        <div className="modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="modal-title">
          <div className="order-success-modal animate-scale-up">
            <div className="success-icon-wrap">
              <CheckCircle2 size={54} className="icon-success" />
            </div>
            <span className="badge-order-ready">Order Transmitted to Kitchen</span>
            <h2 id="modal-title" className="modal-title">Pickup Order Confirmed!</h2>
            <div className="order-token-box">
              <span className="token-label">YOUR PICKUP TOKEN</span>
              <strong className="token-number">{orderConfirmed.id}</strong>
              <span className="token-sub">Show this screen or token at the counter</span>
            </div>

            <div className="order-details-card">
              <div className="detail-row">
                <span>Location</span>
                <strong>{orderConfirmed.pickupCounter}</strong>
              </div>
              <div className="detail-row">
                <span>Estimated Prep Time</span>
                <strong className="text-amber">
                  <Clock size={14} style={{ display: 'inline', verticalAlign: '-2px', marginRight: '4px' }} />
                  ~{orderConfirmed.prepMins} minutes
                </strong>
              </div>
              <div className="detail-row">
                <span>Total Items</span>
                <strong>{orderConfirmed.itemsCount} dishes</strong>
              </div>
              <div className="detail-row total-row">
                <span>Amount Paid</span>
                <strong>${orderConfirmed.totalPaid.toFixed(2)}</strong>
              </div>
            </div>

            <button type="button" className="btn-modal-done" onClick={handleDoneOrder}>
              Start New Order & Back to Menu
            </button>
          </div>
        </div>
      )}

      {/* Cart Layout: Two Columns on Tablet/Desktop, Stacked on Mobile */}
      <div className="cart-grid-layout">
        {/* Left Column: Cart Items List */}
        <section className="cart-items-column" aria-label="Order Items">
          <div className="cart-header-bar">
            <h2 className="cart-heading">
              Your Order Tray ({totalCount} {totalCount === 1 ? 'item' : 'items'})
            </h2>
            <button
              type="button"
              className="btn-clear-cart"
              onClick={clearCart}
              title="Remove all items"
            >
              Clear Tray
            </button>
          </div>

          <div className="cart-items-list">
            {cartItems.map((item) => (
              <article key={item.cartItemId} className="cart-item-card">
                <img
                  src={item.image}
                  alt={item.name}
                  className="cart-item-img"
                  onError={(e) => {
                    e.target.src = '/assets/burger.jpg';
                  }}
                />

                <div className="cart-item-info">
                  <div className="item-title-row">
                    <h3 className="cart-item-name">
                      <Link to={`/item/${item.id}`}>{item.name}</Link>
                    </h3>
                    <span className="cart-item-total">${item.itemTotalPrice.toFixed(2)}</span>
                  </div>

                  <div className="cart-item-unit-price">
                    ${item.unitPrice.toFixed(2)} each
                  </div>

                  {/* Add-ons list if any */}
                  {item.selectedAddons && item.selectedAddons.length > 0 && (
                    <div className="cart-addons-tags">
                      {item.selectedAddons.map((addon) => (
                        <span key={addon.id} className="addon-tag">
                          +{addon.name} (+${Number(addon.price).toFixed(2)})
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Special Notes if any */}
                  {item.notes && (
                    <div className="cart-item-note">
                      <em>Note:</em> "{item.notes}"
                    </div>
                  )}

                  {/* Quantity Stepper & Delete */}
                  <div className="cart-item-controls">
                    <div className="qty-stepper" aria-label={`Quantity for ${item.name}`}>
                      <button
                        type="button"
                        className="qty-btn"
                        onClick={() => updateQuantity(item.cartItemId, item.quantity - 1)}
                        aria-label="Decrease quantity"
                      >
                        <Minus size={14} />
                      </button>
                      <span className="qty-count">{item.quantity}</span>
                      <button
                        type="button"
                        className="qty-btn"
                        onClick={() => updateQuantity(item.cartItemId, item.quantity + 1)}
                        aria-label="Increase quantity"
                      >
                        <Plus size={14} />
                      </button>
                    </div>

                    <button
                      type="button"
                      className="btn-remove-item"
                      onClick={() => removeFromCart(item.cartItemId)}
                      aria-label={`Remove ${item.name}`}
                      title="Remove dish"
                    >
                      <Trash2 size={16} />
                      <span className="remove-label">Remove</span>
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>

          {/* Kitchen Instructions */}
          <div className="order-notes-box">
            <label htmlFor="canteen-kitchen-notes" className="notes-label">
              Special Kitchen Instructions (Optional)
            </label>
            <textarea
              id="canteen-kitchen-notes"
              rows={2}
              className="notes-textarea"
              placeholder="e.g. Cut burger in half, extra napkins, serve dressing on the side..."
              value={orderNotes}
              onChange={(e) => setOrderNotes(e.target.value)}
            />
          </div>
        </section>

        {/* Right Column: Order Summary & Checkout */}
        <aside className="cart-summary-column" aria-label="Order Summary">
          <div className="summary-card">
            <h3 className="summary-title">Order Summary</h3>

            {/* Promo Code Form */}
            <form onSubmit={handleApplyPromo} className="promo-form">
              <label htmlFor="promo-input" className="sr-only">
                Enter Promo or Student Code
              </label>
              <div className="promo-input-group">
                <Tag size={16} className="promo-input-icon" />
                <input
                  id="promo-input"
                  type="text"
                  placeholder="Code (Try STUDENT15)"
                  className="promo-input"
                  value={inputCode}
                  onChange={(e) => setInputCode(e.target.value)}
                />
                <button type="submit" className="btn-apply-promo">
                  Apply
                </button>
              </div>
              {promoMessage && (
                <p className={`promo-status-msg ${promoMessage.isError ? 'msg-error' : 'msg-success'}`}>
                  {promoMessage.text}
                </p>
              )}
            </form>

            {/* Price Calculations */}
            <div className="summary-breakdown">
              <div className="summary-row">
                <span>Dishes Subtotal ({totalCount} items)</span>
                <span>${cartSubtotal.toFixed(2)}</span>
              </div>

              {discountPercent > 0 && (
                <div className="summary-row discount-row">
                  <span className="discount-label">
                    <Sparkles size={14} /> Student Perk ({promoCode} - {discountPercent}%)
                  </span>
                  <span className="discount-val">-${discountAmount.toFixed(2)}</span>
                </div>
              )}

              <div className="summary-row">
                <span>Campus Dining Fee</span>
                <span className="fee-waived">FREE (Student Hub)</span>
              </div>

              <div className="summary-divider"></div>

              <div className="summary-row summary-total-row">
                <span className="total-label">Total to Pay</span>
                <span className="total-amount">${finalTotal.toFixed(2)}</span>
              </div>
            </div>

            {/* Pickup Location Info */}
            <div className="pickup-notice">
              <Clock size={16} className="notice-icon" />
              <div>
                <strong>Express Campus Pickup</strong>
                <p>Ready in 6-8 mins at Counter 2 (Level 1 Dining Hall)</p>
              </div>
            </div>

            {/* Place Order Button */}
            {allowCheckout && (
              <button
                type="button"
                className={`btn-checkout-primary ${isCheckingOut ? 'loading' : ''}`}
                onClick={handlePlaceOrder}
                disabled={isCheckingOut || cartItems.length === 0}
              >
                {isCheckingOut ? (
                  <span>Transmitting to Kitchen...</span>
                ) : (
                  <>
                    <span>Place Campus Order • ${finalTotal.toFixed(2)}</span>
                    <ArrowRight size={18} />
                  </>
                )}
              </button>
            )}

            <div className="continue-shopping-wrap">
              <Link to="/" className="link-back-menu">
                <ChevronLeft size={16} /> Continue Browsing Menu
              </Link>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
