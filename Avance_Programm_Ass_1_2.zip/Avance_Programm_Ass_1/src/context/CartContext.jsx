import React, { createContext, useContext, useState, useEffect } from 'react';

const CartContext = createContext();

export function CartProvider({ children }) {
  // Cart state persisted to localStorage for realistic canteen experience
  const [cartItems, setCartItems] = useState(() => {
    try {
      const saved = localStorage.getItem('unibites_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Favorites state persisted to localStorage
  const [favorites, setFavorites] = useState(() => {
    try {
      const saved = localStorage.getItem('unibites_favorites');
      return saved ? JSON.parse(saved) : ['item-1', 'item-3']; // Default sample favorites
    } catch {
      return ['item-1', 'item-3'];
    }
  });

  // Promo code state
  const [promoCode, setPromoCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [promoMessage, setPromoMessage] = useState(null);

  // Toast feedback state
  const [toast, setToast] = useState(null);

  useEffect(() => {
    try {
      localStorage.setItem('unibites_cart', JSON.stringify(cartItems));
    } catch (e) {
      console.error('Failed to save cart to localStorage', e);
    }
  }, [cartItems]);

  useEffect(() => {
    try {
      localStorage.setItem('unibites_favorites', JSON.stringify(favorites));
    } catch (e) {
      console.error('Failed to save favorites to localStorage', e);
    }
  }, [favorites]);

  const showToast = (message, type = 'success') => {
    setToast({ message, type, id: Date.now() });
    setTimeout(() => {
      setToast((prev) => (prev && prev.message === message ? null : prev));
    }, 3200);
  };

  // Toggle favorite status
  const toggleFavorite = (itemId) => {
    setFavorites((prev) => {
      const isFav = prev.includes(itemId);
      const updated = isFav ? prev.filter((id) => id !== itemId) : [...prev, itemId];
      showToast(isFav ? 'Removed from favorites' : 'Saved to your favorites! ❤️', 'info');
      return updated;
    });
  };

  const isFavorite = (itemId) => favorites.includes(itemId);

  // Add item to cart with optional addons and special notes
  const addToCart = (item, quantity = 1, selectedAddons = [], notes = '') => {
    const addonsTotal = selectedAddons.reduce((sum, a) => sum + (a.price || 0), 0);
    const itemUnitPrice = Number((item.price + addonsTotal).toFixed(2));
    
    // Sort addon IDs for deterministic comparison
    const sortedAddonIds = selectedAddons.map((a) => a.id).sort().join(',');
    const cartItemId = `${item.id}_${sortedAddonIds}_${notes.trim().toLowerCase()}`;

    setCartItems((prevItems) => {
      const existingIndex = prevItems.findIndex((ci) => ci.cartItemId === cartItemId);
      if (existingIndex > -1) {
        const updated = [...prevItems];
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: updated[existingIndex].quantity + quantity,
          itemTotalPrice: Number(
            ((updated[existingIndex].quantity + quantity) * itemUnitPrice).toFixed(2)
          )
        };
        return updated;
      } else {
        const newItem = {
          cartItemId,
          id: item.id,
          name: item.name,
          category: item.category,
          basePrice: item.price,
          unitPrice: itemUnitPrice,
          image: item.image,
          quantity,
          selectedAddons,
          notes,
          itemTotalPrice: Number((quantity * itemUnitPrice).toFixed(2))
        };
        return [...prevItems, newItem];
      }
    });

    showToast(`Added ${quantity}x "${item.name}" to your order tray! 🛒`);
  };

  // Update item quantity
  const updateQuantity = (cartItemId, newQuantity) => {
    if (newQuantity <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setCartItems((prevItems) =>
      prevItems.map((item) => {
        if (item.cartItemId === cartItemId) {
          return {
            ...item,
            quantity: newQuantity,
            itemTotalPrice: Number((newQuantity * item.unitPrice).toFixed(2))
          };
        }
        return item;
      })
    );
  };

  // Remove single line item
  const removeFromCart = (cartItemId) => {
    setCartItems((prevItems) => {
      const removed = prevItems.find((ci) => ci.cartItemId === cartItemId);
      if (removed) {
        showToast(`Removed "${removed.name}" from cart`, 'info');
      }
      return prevItems.filter((item) => item.cartItemId !== cartItemId);
    });
  };

  // Clear entire cart
  const clearCart = () => {
    setCartItems([]);
    setPromoCode('');
    setDiscountPercent(0);
    setPromoMessage(null);
  };

  // Apply promo code (e.g. STUDENT15)
  const applyPromo = (code) => {
    const clean = code.trim().toUpperCase();
    if (!clean) {
      setPromoMessage({ text: 'Please enter a promo code.', isError: true });
      return;
    }
    if (clean === 'STUDENT15') {
      setPromoCode(clean);
      setDiscountPercent(15);
      setPromoMessage({ text: '15% Student Discount applied!', isError: false });
      showToast('15% Student Discount applied! 🎉');
    } else if (clean === 'FREESHIP' || clean === 'CAMPUS10') {
      setPromoCode(clean);
      setDiscountPercent(10);
      setPromoMessage({ text: '10% Campus Perk applied!', isError: false });
      showToast('10% Campus Perk applied!');
    } else {
      setPromoMessage({ text: 'Invalid promo code. Try "STUDENT15"', isError: true });
    }
  };

  // Derived calculations
  const totalCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = Number(
    cartItems.reduce((sum, item) => sum + item.itemTotalPrice, 0).toFixed(2)
  );
  const discountAmount = Number(((cartSubtotal * discountPercent) / 100).toFixed(2));
  const finalTotal = Number(Math.max(0, cartSubtotal - discountAmount).toFixed(2));

  return (
    <CartContext.Provider
      value={{
        cartItems,
        totalCount,
        cartSubtotal,
        discountPercent,
        discountAmount,
        finalTotal,
        promoCode,
        promoMessage,
        favorites,
        toast,
        addToCart,
        updateQuantity,
        removeFromCart,
        clearCart,
        applyPromo,
        toggleFavorite,
        isFavorite,
        showToast
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
