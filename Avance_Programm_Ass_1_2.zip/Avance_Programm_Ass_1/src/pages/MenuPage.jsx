import React, { useState, useEffect } from 'react';
import MenuList from '../components/MenuList';
import { useCart } from '../context/CartContext';
import {
  Search,
  X,
  Heart,
  SlidersHorizontal,
  Flame,
  Leaf,
  ShieldCheck,
  Wheat,
  Coffee,
  UtensilsCrossed,
  Pizza,
  Sandwich,
  Soup,
  Croissant,
  Cake,
  Popcorn,
  Zap,
  Tag,
  Copy
} from 'lucide-react';

export default function MenuPage({ showFavoritesOnly, setShowFavoritesOnly }) {
  const { isFavorite, favorites, showToast } = useCart();

  // Menu items loaded from local JSON file
  const [menuItems, setMenuItems] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedDietary, setSelectedDietary] = useState('all'); // 'all', 'halal', 'veg', 'vegan', 'gluten-free'

  // Categories list
  const CATEGORIES = [
    { id: 'all', label: 'All Items', icon: UtensilsCrossed },
    { id: 'burgers', label: 'Burgers & Wraps', icon: Sandwich },
    { id: 'mains', label: 'Mains & Pasta', icon: UtensilsCrossed },
    { id: 'bowls', label: 'Power Bowls', icon: Soup },
    { id: 'pizza', label: 'Stone Pizza', icon: Pizza },
    { id: 'beverages', label: 'Coffee & Drinks', icon: Coffee },
    { id: 'breakfast', label: 'Breakfast', icon: Croissant },
    { id: 'snacks', label: 'Sides & Snacks', icon: Popcorn },
    { id: 'desserts', label: 'Desserts', icon: Cake }
  ];

  // DIETARY FILTERS
  const DIETARY_OPTIONS = [
    { id: 'all', label: 'All Diets' },
    { id: 'halal', label: 'Halal Certified', icon: ShieldCheck },
    { id: 'veg', label: 'Vegetarian', icon: Leaf },
    { id: 'vegan', label: '100% Vegan', icon: Leaf },
    { id: 'gluten-free', label: 'Gluten-Free', icon: Wheat }
  ];

  // Fetch menu.json using useEffect with async/await
  const fetchMenuData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      // Load from local menu.json file
      const response = await fetch('/menu.json');
      if (!response.ok) {
        throw new Error(`Failed to load menu: HTTP ${response.status} ${response.statusText}`);
      }
      const data = await response.json();
      if (!Array.isArray(data)) {
        throw new Error('Invalid menu data structure received from menu.json');
      }
      setMenuItems(data);
    } catch (err) {
      console.error('Error fetching menu.json:', err);
      setError(err.message || 'Unable to connect to the canteen menu file.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchMenuData();
  }, []);

  // Filter items according to search, category, dietary, and favorites
  const filteredItems = menuItems.filter((item) => {
    // 1. Favorites filter
    if (showFavoritesOnly && !isFavorite(item.id)) {
      return false;
    }

    // 2. Category filter
    if (selectedCategory !== 'all') {
      if (item.category.toLowerCase() !== selectedCategory.toLowerCase()) {
        return false;
      }
    }

    // 3. Dietary filter
    if (selectedDietary !== 'all') {
      if (!item.dietary || !item.dietary.includes(selectedDietary)) {
        return false;
      }
    }

    // 4. Search query filter (matches name, description, category, badge)
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchName = item.name.toLowerCase().includes(q);
      const matchDesc = item.description?.toLowerCase().includes(q);
      const matchCat = item.category.toLowerCase().includes(q);
      const matchBadge = item.badge?.toLowerCase().includes(q);
      if (!matchName && !matchDesc && !matchCat && !matchBadge) {
        return false;
      }
    }

    return true;
  });

  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedDietary('all');
    if (setShowFavoritesOnly) setShowFavoritesOnly(false);
  };

  return (
    <div className="menu-page">
      {/* Hero Welcome Banner */}
      <section className="hero-section" aria-label="Canteen Welcome">
        <div className="hero-content">
          <div className="hero-pill">
            <span className="pill-dot"></span> Freshly Prepared Every Day
          </div>
          <h2 className="hero-title">
            Delicious Campus Bites, <br className="break-desktop" />
            <span className="gradient-text">Ready for Quick Pickup</span>
          </h2>
          <p className="hero-subtitle">
            Browse today’s canteen menu, customize your favorite dishes, and order straight from your phone with student perks.
          </p>
          <div className="hero-stats">
            <div className="hero-stat"><strong>12+</strong><span>Fresh dishes</span></div>
            <div className="hero-stat"><strong>4.8★</strong><span>Student rating</span></div>
            <div className="hero-stat"><strong>6 min</strong><span>Avg. prep</span></div>
          </div>
        </div>

        {/* Floating food photos */}
        <div className="hero-visual" aria-hidden="true">
          <img className="hero-photo hero-photo-1" src="/assets/burger.jpg" alt="" />
          <img className="hero-photo hero-photo-2" src="/assets/pizza.jpg" alt="" />
          <img className="hero-photo hero-photo-3" src="/assets/coffee.jpg" alt="" />
          <span className="hero-emoji emoji-1">🍔</span>
          <span className="hero-emoji emoji-2">🍕</span>
          <span className="hero-emoji emoji-3">☕</span>
          <span className="hero-emoji emoji-4">🍩</span>
        </div>
      </section>

      {/* Why UniBites strip */}
      <section className="features-strip" aria-label="Why choose UniBites">
        <div className="feature-card feature-orange">
          <div className="feature-icon"><Zap size={22} /></div>
          <div><h3>Super Fast</h3><p>Ready in 6-8 minutes</p></div>
        </div>
        <div className="feature-card feature-pink">
          <div className="feature-icon"><Tag size={22} /></div>
          <div><h3>Student Deals</h3><p>15% off with STUDENT15</p></div>
        </div>
        <div className="feature-card feature-teal">
          <div className="feature-icon"><Leaf size={22} /></div>
          <div><h3>Fresh Daily</h3><p>Cooked every morning</p></div>
        </div>
        <div className="feature-card feature-purple">
          <div className="feature-icon"><ShieldCheck size={22} /></div>
          <div><h3>Halal Options</h3><p>Certified & labelled</p></div>
        </div>
      </section>

      {/* Filter and Search Bar Section */}
      <section className="controls-section" aria-label="Search and Filter Menu">
        <div className="search-filter-card">
          {/* Search Box Input */}
          <div className="search-input-wrap">
            <Search size={18} className="search-icon" aria-hidden="true" />
            <input
              type="text"
              id="canteen-search-input"
              className="search-input"
              placeholder="Search dishes, burgers, pasta, iced coffee..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              aria-label="Search menu items"
            />
            {searchQuery && (
              <button
                type="button"
                className="search-clear-btn"
                onClick={() => setSearchQuery('')}
                aria-label="Clear search query"
              >
                <X size={16} />
              </button>
            )}
          </div>

          {/* Favorites quick toggle button */}
          <button
            type="button"
            className={`fav-filter-pill ${showFavoritesOnly ? 'active' : ''}`}
            onClick={() => setShowFavoritesOnly && setShowFavoritesOnly((prev) => !prev)}
            aria-pressed={showFavoritesOnly}
          >
            <Heart size={16} className={showFavoritesOnly ? 'fill-current' : ''} />
            <span>Favorites</span>
            <span className="badge-bubble">{favorites.length}</span>
          </button>
        </div>

        {/* Categories Horizontal Carousel */}
        <div className="categories-scroll-wrapper" role="region" aria-label="Menu Categories">
          <div className="categories-list">
            {CATEGORIES.map((cat) => {
              const Icon = cat.icon;
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  className={`category-pill ${isSelected ? 'active' : ''}`}
                  onClick={() => setSelectedCategory(cat.id)}
                  aria-pressed={isSelected}
                >
                  <Icon size={16} />
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Dietary Preferences Filter Row */}
        <div className="dietary-row" aria-label="Dietary Filters">
          <span className="dietary-title">
            <SlidersHorizontal size={14} /> Dietary:
          </span>
          <div className="dietary-pills">
            {DIETARY_OPTIONS.map((opt) => (
              <button
                key={opt.id}
                type="button"
                className={`dietary-chip ${selectedDietary === opt.id ? 'active' : ''}`}
                onClick={() => setSelectedDietary(opt.id)}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Menu List of Cards */}
      <MenuList
        items={filteredItems}
        isLoading={isLoading}
        error={error}
        onRetry={fetchMenuData}
        onClearFilters={handleClearFilters}
        searchQuery={searchQuery}
        selectedCategory={selectedCategory}
        showFavoritesOnly={showFavoritesOnly}
      />

      {/* Student deal banner */}
      <section className="deal-banner" aria-label="Student deal">
        <div className="deal-text">
          <span className="deal-pill">🎓 Student Special</span>
          <h3 className="deal-title">Get 15% OFF your whole tray!</h3>
          <p className="deal-desc">Apply the code at checkout and enjoy campus meals for less.</p>
          <button
            type="button"
            className="deal-code-btn"
            onClick={() => {
              if (navigator.clipboard) navigator.clipboard.writeText('STUDENT15').catch(() => {});
              showToast('Code STUDENT15 copied! 🎉');
            }}
          >
            <span>STUDENT15</span>
            <Copy size={16} />
          </button>
        </div>
        <div className="deal-visual" aria-hidden="true">
          <img className="deal-photo deal-photo-1" src="/assets/bowl.jpg" alt="" />
          <img className="deal-photo deal-photo-2" src="/assets/wrap.jpg" alt="" />
        </div>
      </section>
    </div>
  );
}
