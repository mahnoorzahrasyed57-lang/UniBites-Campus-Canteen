import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import {
  ChevronLeft,
  Heart,
  Star,
  Clock,
  Flame,
  Plus,
  Minus,
  ShoppingBag,
  AlertCircle
} from 'lucide-react';

export default function ItemPage() {
  const { id } = useParams();
  const { addToCart, toggleFavorite, isFavorite } = useCart();

  const [item, setItem] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const [quantity, setQuantity] = useState(1);
  const [selectedAddonIds, setSelectedAddonIds] = useState([]);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const res = await fetch('/menu.json');
        if (!res.ok) throw new Error(`Failed to load menu: HTTP ${res.status}`);
        const data = await res.json();
        const found = data.find((m) => m.id === id);
        if (!cancelled) {
          setItem(found || null);
          setQuantity(1);
          setSelectedAddonIds([]);
          setNotes('');
        }
      } catch (err) {
        if (!cancelled) setError(err.message || 'Could not load this dish.');
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    };
    load();
    return () => {
      cancelled = true;
    };
  }, [id]);

  if (isLoading) {
    return (
      <div className="item-page">
        <div className="skeleton-card item-skeleton">
          <div className="skeleton-img"></div>
        </div>
      </div>
    );
  }

  if (error || !item) {
    return (
      <section className="menu-error-box" role="alert">
        <AlertCircle size={44} className="error-icon" />
        <h3 className="error-title">{error ? "Couldn't load this dish" : 'Dish not found'}</h3>
        <p className="error-desc">{error || 'This dish is not on today\'s menu.'}</p>
        <Link to="/" className="btn-retry">
          <ChevronLeft size={16} />
          <span>Back to Menu</span>
        </Link>
      </section>
    );
  }

  const fav = isFavorite(item.id);
  const addons = item.addons || [];
  const selectedAddons = addons.filter((a) => selectedAddonIds.includes(a.id));
  const addonsTotal = selectedAddons.reduce((sum, a) => sum + a.price, 0);
  const lineTotal = (Number(item.price) + addonsTotal) * quantity;

  const toggleAddon = (addonId) => {
    setSelectedAddonIds((prev) =>
      prev.includes(addonId) ? prev.filter((a) => a !== addonId) : [...prev, addonId]
    );
  };

  const handleAdd = () => {
    addToCart(item, quantity, selectedAddons, notes);
    setQuantity(1);
    setSelectedAddonIds([]);
    setNotes('');
  };

  return (
    <div className="item-page">
      <Link to="/" className="link-back-menu item-back">
        <ChevronLeft size={16} /> Back to Menu
      </Link>

      <div className="item-detail-grid">
        {/* Left: Photo */}
        <div className="item-detail-media">
          <img
            src={item.image}
            alt={item.name}
            className="item-detail-img"
            onError={(e) => {
              e.target.src = '/assets/burger.jpg';
            }}
          />
          <div className="card-top-badges">
            {item.badge && <span className="card-badge-highlight">{item.badge}</span>}
            {item.isSpicy && (
              <span className="card-badge-spicy">
                <Flame size={12} /> Spicy
              </span>
            )}
          </div>
          <button
            type="button"
            className={`card-fav-btn ${fav ? 'favorited' : ''}`}
            onClick={() => toggleFavorite(item.id)}
            aria-label={fav ? 'Remove from favorites' : 'Save to favorites'}
          >
            <Heart size={18} fill={fav ? '#ef4444' : 'none'} stroke={fav ? '#ef4444' : '#475569'} />
          </button>
        </div>

        {/* Right: Info */}
        <div className="item-detail-info">
          <div className="card-meta-row">
            <span className="card-category">{item.category}</span>
            <div className="card-rating">
              <Star size={14} className="star-icon" fill="#f59e0b" stroke="#f59e0b" />
              <span className="rating-num">{item.rating}</span>
              <span className="rating-count">({item.reviews} reviews)</span>
            </div>
          </div>

          <h2 className="item-detail-title">{item.name}</h2>
          <p className="item-detail-desc">{item.description}</p>

          <div className="card-chips">
            <span className="chip-item">
              <Clock size={12} /> {item.prepTime}
            </span>
            <span className="chip-item">{item.calories} kcal</span>
            {item.dietary?.map((diet) => (
              <span key={diet} className={`chip-diet chip-${diet}`}>
                {diet}
              </span>
            ))}
          </div>

          <div className="facts-grid">
            <div className="fact-box fact-orange">
              <span>Calories</span>
              <strong>{item.calories}</strong>
            </div>
            <div className="fact-box fact-pink">
              <span>Protein</span>
              <strong>{item.protein}</strong>
            </div>
            <div className="fact-box fact-purple">
              <span>Prep time</span>
              <strong>{item.prepTime}</strong>
            </div>
            <div className="fact-box fact-teal">
              <span>Allergens</span>
              <strong>{item.allergens}</strong>
            </div>
          </div>

          <div className="price-wrap item-price">
            <span className="price-current">${Number(item.price).toFixed(2)}</span>
            {item.originalPrice && (
              <span className="price-original">${Number(item.originalPrice).toFixed(2)}</span>
            )}
          </div>

          {/* Add-ons */}
          {addons.length > 0 && (
            <div className="addons-box">
              <h3 className="addons-title">Customize your meal ✨</h3>
              <div className="addons-list">
                {addons.map((addon) => {
                  const checked = selectedAddonIds.includes(addon.id);
                  return (
                    <label key={addon.id} className={`addon-option ${checked ? 'checked' : ''}`}>
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggleAddon(addon.id)}
                      />
                      <span className="addon-name">{addon.name}</span>
                      <span className="addon-price">+${addon.price.toFixed(2)}</span>
                    </label>
                  );
                })}
              </div>
            </div>
          )}

          <div className="order-notes-box">
            <label htmlFor="item-notes" className="notes-label">
              Special instructions (optional)
            </label>
            <textarea
              id="item-notes"
              rows={2}
              className="notes-textarea"
              placeholder="e.g. No onions, extra napkins..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>

          {/* Quantity + Add button */}
          <div className="item-action-bar">
            <div className="qty-stepper">
              <button
                type="button"
                className="qty-btn"
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                aria-label="Decrease quantity"
              >
                <Minus size={14} />
              </button>
              <span className="qty-count">{quantity}</span>
              <button
                type="button"
                className="qty-btn"
                onClick={() => setQuantity((q) => q + 1)}
                aria-label="Increase quantity"
              >
                <Plus size={14} />
              </button>
            </div>

            <button type="button" className="btn-checkout-primary" onClick={handleAdd}>
              <ShoppingBag size={18} />
              <span>Add to Tray • ${lineTotal.toFixed(2)}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
