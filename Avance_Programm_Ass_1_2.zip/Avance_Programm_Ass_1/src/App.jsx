import React, { useState, useEffect } from 'react';
import { ArrowUp, Utensils, Clock, MapPin, Sparkles } from 'lucide-react';
import { Routes, Route, useLocation, useNavigate, Link } from 'react-router-dom';
import { CartProvider, useCart } from './context/CartContext';
import Header from './components/Header';
import MenuPage from './pages/MenuPage';
import ItemPage from './pages/ItemPage';
import Cart from './components/Cart';

function Shell() {
  const { toast } = useCart();
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const [showFavoritesOnly, setShowFavoritesOnlyState] = useState(false);
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 500);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Always go back to the menu when the favorites filter is used from another page
  const setShowFavoritesOnly = (value) => {
    setShowFavoritesOnlyState(value);
    if (pathname !== '/') navigate('/');
  };

  // Scroll to the top whenever the page changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return (
    <div className="app-shell">
      <Header
        showFavoritesOnly={showFavoritesOnly}
        setShowFavoritesOnly={setShowFavoritesOnly}
      />

      <main className="container main-content">
        <Routes>
          <Route
            path="/"
            element={
              <MenuPage
                showFavoritesOnly={showFavoritesOnly}
                setShowFavoritesOnly={setShowFavoritesOnlyState}
              />
            }
          />
          <Route path="/cart" element={<Cart />} />
          <Route path="/item/:id" element={<ItemPage />} />
          <Route
            path="*"
            element={
              <div className="empty-results-box">
                <h3 className="empty-title">Page not found 🍽️</h3>
                <p className="empty-desc">This page is not on our menu.</p>
                <Link to="/" className="btn-clear-filters">
                  Back to Menu
                </Link>
              </div>
            }
          />
        </Routes>
      </main>

      <footer className="app-footer">
        <svg className="footer-wave" viewBox="0 0 1440 80" preserveAspectRatio="none" aria-hidden="true">
          <path d="M0 40 C240 90 480 0 720 40 C960 80 1200 10 1440 40 V80 H0Z" fill="currentColor" />
        </svg>
        <div className="footer-body">
          <div className="container footer-grid">
            <div className="footer-col">
              <div className="footer-brand">
                <span className="footer-logo"><Utensils size={18} /></span>
                <span>UniBites<span className="brand-accent">.</span></span>
              </div>
              <p>Fresh, fast and friendly food for hungry students.</p>
            </div>
            <div className="footer-col">
              <h4><Clock size={15} /> Opening Hours</h4>
              <p>Mon – Fri: 7:30 AM – 8:30 PM</p>
              <p>Sat: 9:00 AM – 5:00 PM</p>
            </div>
            <div className="footer-col">
              <h4><MapPin size={15} /> Find Us</h4>
              <p>Campus Dining Hall, Level 1</p>
              <p>Express Pickup Counter 2</p>
            </div>
            <div className="footer-col">
              <h4><Sparkles size={15} /> Student Perk</h4>
              <p>Use code <strong>STUDENT15</strong> for 15% off</p>
            </div>
          </div>
          <div className="container footer-bottom">
            Made with <span className="footer-heart">❤</span> for hungry students • UniBites Campus Canteen
          </div>
        </div>
      </footer>

      <button
        type="button"
        className={`back-to-top ${showTop ? 'visible' : ''}`}
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        aria-label="Back to top"
      >
        <ArrowUp size={20} />
      </button>

      {toast && (
        <div key={toast.id} className={`toast-box toast-${toast.type}`} role="status">
          {toast.message}
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <CartProvider>
      <Shell />
    </CartProvider>
  );
}
