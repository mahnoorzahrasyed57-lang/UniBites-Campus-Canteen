/**
 * UniBites Campus Canteen - Frontend Logic
 * Assignment 1 — Campus Canteen Menu (Frontend only)
 */

(function () {
  'use strict';

  /* ==========================================================================
     1. Menu Data Collection (12 Rich Items across 6 Categories)
     ========================================================================== */
  const MENU_ITEMS = [
    {
      id: 'item-1',
      name: "The Dean's Gourmet Burger",
      category: 'burgers',
      price: 4.80,
      originalPrice: 5.80,
      image: 'assets/burger.jpg',
      rating: 4.9,
      reviews: 184,
      calories: 620,
      protein: '32g',
      prepTime: '8-10 min',
      allergens: 'Dairy, Gluten',
      dietary: ['halal'],
      isBudget: false,
      isSpicy: false,
      isSpecial: true,
      description: 'Hand-pressed Angus beef patty with melted sharp cheddar, crisp butterhead lettuce, vine tomato, and signature canteen sauce on a brioche bun with golden fries.',
      addons: [
        { id: 'extra_cheese', name: 'Extra Melted Cheddar', price: 0.60 },
        { id: 'double_patty', name: 'Double Beef Patty', price: 1.80 },
        { id: 'jalapenos', name: 'Pickled Jalapenos', price: 0.40 },
        { id: 'gluten_bun', name: 'Gluten-Free Brioche Bun', price: 0.50 }
      ]
    },
    {
      id: 'item-2',
      name: 'Tuscan Chicken Alfredo Fettuccine',
      category: 'mains',
      price: 5.60,
      originalPrice: 6.80,
      image: 'assets/pasta.jpg',
      rating: 4.8,
      reviews: 142,
      calories: 580,
      protein: '28g',
      prepTime: '10-12 min',
      allergens: 'Dairy, Gluten',
      dietary: ['halal'],
      isBudget: false,
      isSpicy: false,
      isSpecial: true,
      description: 'Al dente fettuccine pasta swirled in slow-simmered garlic parmesan white cream sauce, topped with herb-grilled chicken slices and toasted garlic focaccia.',
      addons: [
        { id: 'extra_chicken', name: 'Extra Herb Chicken (80g)', price: 1.50 },
        { id: 'parm_shavings', name: 'Aged Parmesan Shavings', price: 0.70 },
        { id: 'mushrooms', name: 'Sauteed Wild Mushrooms', price: 0.60 }
      ]
    },
    {
      id: 'item-3',
      name: 'Signature Iced Caramel Cold Brew',
      category: 'beverages',
      price: 2.80,
      originalPrice: 3.50,
      image: 'assets/coffee.jpg',
      rating: 4.9,
      reviews: 215,
      calories: 160,
      protein: '3g',
      prepTime: '3-5 min',
      allergens: 'Dairy (Oat milk alternative available)',
      dietary: ['veg'],
      isBudget: true,
      isSpicy: false,
      isSpecial: false,
      description: '16-hour slow-dripped single origin Arabica cold brew, cascading with creamy oat milk, sea salt caramel drizzle, and velvety chilled foam.',
      addons: [
        { id: 'extra_shot', name: 'Extra Espresso Shot', price: 0.70 },
        { id: 'vanilla_syrup', name: 'Sugar-Free Vanilla Syrup', price: 0.40 },
        { id: 'boba_pearls', name: 'Brown Sugar Boba', price: 0.60 }
      ]
    },
    {
      id: 'item-4',
      name: 'Wood-Fired Margherita Personal Pizza',
      category: 'pizza',
      price: 5.20,
      originalPrice: 6.20,
      image: 'assets/pizza.jpg',
      rating: 4.7,
      reviews: 98,
      calories: 540,
      protein: '20g',
      prepTime: '8-10 min',
      allergens: 'Dairy, Gluten',
      dietary: ['veg'],
      isBudget: false,
      isSpicy: false,
      isSpecial: true,
      description: 'Crisp stone-baked sourdough crust topped with San Marzano tomato puree, buffalo mozzarella fior di latte, fresh sweet basil leaves, and extra virgin olive oil.',
      addons: [
        { id: 'extra_mozz', name: 'Double Mozzarella', price: 0.90 },
        { id: 'chili_oil', name: 'Spicy Chili Infused Olive Oil', price: 0.30 },
        { id: 'bell_peppers', name: 'Charred Bell Peppers', price: 0.50 }
      ]
    },
    {
      id: 'item-5',
      name: 'Chipotle Grilled Chicken Club Wrap',
      category: 'burgers',
      price: 4.40,
      originalPrice: 5.20,
      image: 'assets/wrap.jpg',
      rating: 4.8,
      reviews: 163,
      calories: 460,
      protein: '26g',
      prepTime: '6-8 min',
      allergens: 'Dairy, Gluten',
      dietary: ['halal'],
      isBudget: false,
      isSpicy: true,
      isSpecial: false,
      description: 'Golden griddled flour tortilla stuffed with smoky chipotle grilled chicken strips, Hass avocado slices, pepperjack cheese, shredded crisp lettuce, and cilantro crema.',
      addons: [
        { id: 'extra_avo', name: 'Extra Avocado Mash', price: 0.80 },
        { id: 'spicy_sauce', name: 'Ghost Pepper Hot Drizzle', price: 0.40 },
        { id: 'sour_cream', name: 'Cool Lime Sour Cream', price: 0.40 }
      ]
    },
    {
      id: 'item-6',
      name: 'Mediterranean Falafel & Quinoa Power Bowl',
      category: 'bowls',
      price: 4.90,
      originalPrice: 5.90,
      image: 'assets/bowl.jpg',
      rating: 4.9,
      reviews: 118,
      calories: 420,
      protein: '18g',
      prepTime: '5-7 min',
      allergens: 'Sesame (Tahini)',
      dietary: ['vegan', 'veg', 'gluten-free'],
      isBudget: false,
      isSpicy: false,
      isSpecial: false,
      description: 'Crisp hand-rolled falafel croquettes, fluffy tricolor quinoa, lemon roasted chickpeas, house hummus, heirloom tomatoes, English cucumbers, and roasted garlic tahini.',
      addons: [
        { id: 'extra_falafel', name: '3x Extra Falafel Balls', price: 1.00 },
        { id: 'kalamata_olives', name: 'Greek Kalamata Olives', price: 0.60 },
        { id: 'pita_pocket', name: 'Warm Pita Pocket (2x)', price: 0.70 }
      ]
    },
    {
      id: 'item-7',
      name: 'Crunchy Mozzarella Sticks & Marinara',
      category: 'burgers',
      price: 3.20,
      originalPrice: 3.90,
      image: 'assets/burger.jpg',
      rating: 4.6,
      reviews: 89,
      calories: 360,
      protein: '14g',
      prepTime: '5-6 min',
      allergens: 'Dairy, Gluten',
      dietary: ['veg'],
      isBudget: true,
      isSpicy: false,
      isSpecial: false,
      description: 'Five crisp herb-seasoned breaded mozzarella batons fried to a bubbly golden crunch, served with our signature tangy tomato basil dip.',
      addons: [
        { id: 'extra_marinara', name: 'Extra Marinara Cup', price: 0.40 },
        { id: 'garlic_mayo', name: 'Garlic Aioli Dip', price: 0.40 }
      ]
    },
    {
      id: 'item-8',
      name: 'Spicy Shredded Chicken Street Tacos (2 pcs)',
      category: 'mains',
      price: 3.90,
      originalPrice: 4.80,
      image: 'assets/wrap.jpg',
      rating: 4.7,
      reviews: 104,
      calories: 410,
      protein: '22g',
      prepTime: '6-8 min',
      allergens: 'Dairy (Crema)',
      dietary: ['halal', 'gluten-free'],
      isBudget: true,
      isSpicy: true,
      isSpecial: false,
      description: 'Two soft yellow corn tortillas packed with spiced pulled chicken tinga, fresh pico de gallo, pickled red onion ribbons, and crumbled cotija cheese.',
      addons: [
        { id: 'extra_taco', name: '+1 Additional Taco', price: 1.80 },
        { id: 'guacamole', name: 'Fresh House Guacamole', price: 0.80 },
        { id: 'habanero_salsa', name: 'Fiery Habanero Salsa', price: 0.35 }
      ]
    },
    {
      id: 'item-9',
      name: 'Buttermilk Blueberry Pancakes Stack',
      category: 'breakfast',
      price: 3.80,
      originalPrice: 4.60,
      image: 'assets/coffee.jpg',
      rating: 4.8,
      reviews: 156,
      calories: 440,
      protein: '11g',
      prepTime: '6-8 min',
      allergens: 'Dairy, Eggs, Gluten',
      dietary: ['veg'],
      isBudget: true,
      isSpicy: false,
      isSpecial: false,
      description: 'Triple stack of fluffy golden buttermilk pancakes infused with wild blueberries, finished with whipped farm butter and genuine amber maple syrup.',
      addons: [
        { id: 'fresh_strawberries', name: 'Fresh Strawberry Medley', price: 0.80 },
        { id: 'whipped_cream', name: 'Extra Whipped Cream Cloud', price: 0.50 },
        { id: 'nutella_drizzle', name: 'Warm Nutella Drizzle', price: 0.70 }
      ]
    },
    {
      id: 'item-10',
      name: 'Ceremonial Matcha Oat Latte & Boba',
      category: 'beverages',
      price: 3.40,
      originalPrice: 4.20,
      image: 'assets/coffee.jpg',
      rating: 4.7,
      reviews: 92,
      calories: 220,
      protein: '4g',
      prepTime: '3-5 min',
      allergens: 'None',
      dietary: ['vegan', 'veg', 'gluten-free'],
      isBudget: true,
      isSpicy: false,
      isSpecial: false,
      description: 'Japanese ceremonial grade green tea matcha whisked with warm creamy oat milk and layered over chewy slow-cooked brown sugar boba pearls.',
      addons: [
        { id: 'cheese_foam', name: 'Salted Cream Cheese Foam', price: 0.60 },
        { id: 'extra_boba', name: 'Double Boba Pearls', price: 0.50 }
      ]
    },
    {
      id: 'item-11',
      name: 'Warm Belgian Chocolate Lava Brownie',
      category: 'breakfast',
      price: 2.90,
      originalPrice: 3.60,
      image: 'assets/pasta.jpg',
      rating: 4.9,
      reviews: 178,
      calories: 390,
      protein: '6g',
      prepTime: '4-5 min',
      allergens: 'Dairy, Eggs, Gluten',
      dietary: ['veg'],
      isBudget: true,
      isSpicy: false,
      isSpecial: false,
      description: 'Baked to order dark chocolate fudge brownie featuring a warm molten chocolate center, dusted with Dutch cocoa and served with vanilla bean ice cream.',
      addons: [
        { id: 'extra_icecream', name: 'Extra Scoop Vanilla Gelato', price: 0.90 },
        { id: 'toasted_walnuts', name: 'Crushed Toasted Walnuts', price: 0.50 }
      ]
    },
    {
      id: 'item-12',
      name: 'Amazonian Acai & Dragonfruit Smoothie Bowl',
      category: 'bowls',
      price: 4.60,
      originalPrice: 5.40,
      image: 'assets/bowl.jpg',
      rating: 4.8,
      reviews: 84,
      calories: 320,
      protein: '9g',
      prepTime: '4-6 min',
      allergens: 'Tree Nuts (Granola, Almond butter)',
      dietary: ['vegan', 'veg', 'gluten-free'],
      isBudget: false,
      isSpicy: false,
      isSpecial: false,
      description: 'Organic wild acai berry blend topped with toasted hemp seed granola, fresh sliced kiwi, sweet dragonfruit, banana coins, and organic chia seeds.',
      addons: [
        { id: 'almond_butter', name: 'Creamy Almond Butter Swirl', price: 0.70 },
        { id: 'cacao_nibs', name: 'Crunchy Raw Cacao Nibs', price: 0.50 }
      ]
    }
  ];

  /* ==========================================================================
     2. Valid Promo Codes Configuration
     ========================================================================== */
  const PROMO_CODES = {
    'STUDENT15': { type: 'percent', value: 15, label: '15% Student Discount' },
    'CAMPUSFIRST': { type: 'fixed', value: 2.00, label: '$2.00 Campus First Order' },
    'FREESHAKE': { type: 'fixed', value: 1.50, label: '$1.50 Beverage Credit' }
  };

  /* ==========================================================================
     Safe LocalStorage Helpers
     ========================================================================== */
  function safeGetStorage(key, defaultValue) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : defaultValue;
    } catch (e) {
      return defaultValue;
    }
  }

  function safeSetStorage(key, value) {
    try {
      localStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value));
    } catch (e) {
      // Ignore storage errors / quota exceptions
    }
  }

  function sanitizeCart(raw) {
    if (!Array.isArray(raw)) return [];
    return raw.filter(line => line && line.item && typeof line.item.id === 'string').map(line => {
      const quantity = Math.max(1, Number(line.quantity) || 1);
      const unitPrice = Number(line.unitPrice) || Number(line.item.price) || 0;
      return {
        ...line,
        quantity,
        unitPrice,
        itemTotalPrice: Number(line.itemTotalPrice) || (quantity * unitPrice),
        addons: Array.isArray(line.addons) ? line.addons : [],
        notes: typeof line.notes === 'string' ? line.notes : ''
      };
    });
  }

  /* ==========================================================================
     3. State Management
     ========================================================================== */
  const state = {
    cart: sanitizeCart(safeGetStorage('unibites_cart', [])),
    favorites: new Set(safeGetStorage('unibites_favorites', [])),
    activeCategory: 'all',
    activeDietary: new Set(),
    searchQuery: '',
    currentSort: 'recommended',
    appliedPromo: null,
    viewMode: 'grid',
    selectedModalItem: null,
    modalQty: 1,
    modalSelectedAddons: []
  };

  /* ==========================================================================
     4. Sound Feedback (Synthesized via Web Audio API)
     ========================================================================== */
  function playAudioChime(type) {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();

      if (type === 'add') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
        osc.frequency.exponentialRampToValueAtTime(783.99, ctx.currentTime + 0.12); // G5
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.25);
      } else if (type === 'success') {
        const notes = [440, 554.37, 659.25, 880];
        notes.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.value = freq;
          gain.gain.setValueAtTime(0.1, ctx.currentTime + idx * 0.08);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.08 + 0.2);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(ctx.currentTime + idx * 0.08);
          osc.stop(ctx.currentTime + idx * 0.08 + 0.22);
        });
      }
    } catch (e) {
      // Audio autoplay policy or unavailable, silently proceed
    }
  }

  /* ==========================================================================
     5. Toast Notification System
     ========================================================================== */
  function showToast(message, icon = '🛒') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span aria-hidden="true">${icon}</span><span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('toast-leave');
      setTimeout(() => toast.remove(), 250);
    }, 2800);
  }

  /* ==========================================================================
     6. Filtering, Searching, & Sorting Engine
     ========================================================================== */
  function getFilteredItems() {
    let list = [...MENU_ITEMS];

    // Filter: Favorites Only (if enabled via header button)
    if (state.activeCategory === 'favorites') {
      list = list.filter(item => state.favorites.has(item.id));
    }
    // Filter: Category
    else if (state.activeCategory !== 'all') {
      list = list.filter(item => item.category === state.activeCategory);
    }

    // Filter: Search Query
    if (state.searchQuery.trim().length > 0) {
      const q = state.searchQuery.toLowerCase().trim();
      list = list.filter(item => 
        item.name.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q)
      );
    }

    // Filter: Multi-Dietary Chips
    state.activeDietary.forEach(diet => {
      if (diet === 'budget') {
        list = list.filter(item => item.price <= 4.00 || item.isBudget);
      } else if (diet === 'spicy') {
        list = list.filter(item => item.isSpicy);
      } else {
        list = list.filter(item => item.dietary && item.dietary.includes(diet));
      }
    });

    // Sorting
    switch (state.currentSort) {
      case 'price-asc':
        list.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        list.sort((a, b) => b.price - a.price);
        break;
      case 'prep-time':
        list.sort((a, b) => {
          const aTime = parseInt(a.prepTime, 10) || 10;
          const bTime = parseInt(b.prepTime, 10) || 10;
          return aTime - bTime;
        });
        break;
      case 'rating':
        list.sort((a, b) => b.rating - a.rating);
        break;
      case 'recommended':
      default:
        // specials first, then high rating
        list.sort((a, b) => (b.isSpecial ? 1 : 0) - (a.isSpecial ? 1 : 0) || b.rating - a.rating);
        break;
    }

    return list;
  }

  /* ==========================================================================
     7. Render Menu Grid
     ========================================================================== */
  function renderMenu() {
    const grid = document.getElementById('menu-grid');
    const emptyCard = document.getElementById('empty-state-card');
    const resultsCountText = document.getElementById('results-count-text');
    const activeFilterSummary = document.getElementById('active-filter-summary');
    const filterSummaryText = document.getElementById('filter-summary-text');

    if (!grid) return;

    const filtered = getFilteredItems();

    // Results count
    if (resultsCountText) {
      resultsCountText.textContent = `Showing ${filtered.length} of ${MENU_ITEMS.length} campus items`;
    }

    // Active filters summary pill
    if (activeFilterSummary && filterSummaryText) {
      const activeFilters = [];
      if (state.activeCategory !== 'all') activeFilters.push(`Category: ${state.activeCategory}`);
      if (state.searchQuery) activeFilters.push(`"${state.searchQuery}"`);
      state.activeDietary.forEach(d => activeFilters.push(d));

      if (activeFilters.length > 0) {
        filterSummaryText.textContent = activeFilters.join(' • ');
        activeFilterSummary.classList.remove('hidden');
      } else {
        activeFilterSummary.classList.add('hidden');
      }
    }

    // Empty state
    if (filtered.length === 0) {
      grid.innerHTML = '';
      if (emptyCard) emptyCard.classList.remove('hidden');
      return;
    } else {
      if (emptyCard) emptyCard.classList.add('hidden');
    }

    // Generate Cards
    grid.innerHTML = filtered.map(item => {
      const isFav = state.favorites.has(item.id);
      const cartQty = getCartItemQuantity(item.id);

      // Dietary badge tags
      const badgesHtml = (item.dietary || []).map(d => {
        const labelMap = {
          'veg': '🌿 Veg',
          'halal': '🍗 Halal',
          'vegan': '🥑 Vegan',
          'gluten-free': '🌾 Gluten-Free'
        };
        return `<span class="badge-pill ${d}">${labelMap[d] || d}</span>`;
      }).join('');

      const spicyBadge = item.isSpicy ? `<span class="badge-pill spicy">🌶️ Spicy</span>` : '';

      return `
        <article class="food-card" data-id="${item.id}" id="card-${item.id}">
          <div class="card-media">
            <img 
              src="${item.image}" 
              alt="${item.name}" 
              class="card-img" 
              loading="lazy"
              onerror="this.onerror=null; this.src='assets/burger.jpg';"
            >
            <div class="card-badges-top">
              ${badgesHtml}
              ${spicyBadge}
            </div>
            <button 
              type="button" 
              class="btn-card-fav ${isFav ? 'is-favorite' : ''}" 
              data-id="${item.id}"
              aria-label="${isFav ? 'Remove from favorites' : 'Add to favorites'}"
              title="Bookmark favorite"
            >
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
              </svg>
            </button>
            <span class="card-prep-tag">⏱️ ${item.prepTime}</span>
          </div>

          <div class="card-content">
            <div class="card-meta-line">
              <span class="card-category">${item.category}</span>
              <span class="card-rating">
                ★ ${item.rating} <span class="card-rating-count">(${item.reviews})</span>
              </span>
            </div>

            <h3 class="card-title">${item.name}</h3>
            <p class="card-desc">${item.description}</p>

            <div class="card-specs-row">
              <span class="card-spec-item" title="Estimated calories">🔥 ${item.calories} kcal</span>
              <span class="card-spec-item" title="Protein amount">💪 ${item.protein}</span>
            </div>

            <div class="card-footer">
              <div class="card-price-group">
                <span class="card-price">$${item.price.toFixed(2)}</span>
                <span class="card-old-price">$${item.originalPrice.toFixed(2)}</span>
              </div>

              <div class="card-button-group">
                <button 
                  type="button" 
                  class="btn-card-details" 
                  data-id="${item.id}" 
                  aria-label="View nutrition & customize ${item.name}"
                  title="Customize & Nutrition"
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="3"></circle>
                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                  </svg>
                </button>

                ${cartQty > 0 ? `
                  <div class="card-qty-pill">
                    <button type="button" class="btn-card-stepper" data-action="card-minus" data-id="${item.id}" aria-label="Decrease quantity">-</button>
                    <span class="card-qty-count">${cartQty}</span>
                    <button type="button" class="btn-card-stepper" data-action="card-plus" data-id="${item.id}" aria-label="Increase quantity">+</button>
                  </div>
                ` : `
                  <button type="button" class="btn-card-add" data-id="${item.id}">
                    <span aria-hidden="true">+</span> Add
                  </button>
                `}
              </div>
            </div>
          </div>
        </article>
      `;
    }).join('');

    updateCategoryCounts();
  }

  /* ==========================================================================
     8. Cart & Tray Management
     ========================================================================== */
  function getCartItemQuantity(itemId) {
    return state.cart
      .filter(line => line.item.id === itemId)
      .reduce((sum, line) => sum + line.quantity, 0);
  }

  function saveCart() {
    safeSetStorage('unibites_cart', state.cart);
    updateCartUI();
  }

  function addToCart(itemId, quantity = 1, addons = [], notes = '') {
    const item = MENU_ITEMS.find(m => m.id === itemId);
    if (!item) return;

    // Check if identical configuration already exists in tray
    const addonIds = addons.map(a => a.id).sort().join(',');
    const existingIndex = state.cart.findIndex(line => 
      line.item.id === itemId && 
      (line.addons || []).map(a => a.id).sort().join(',') === addonIds &&
      (line.notes || '') === notes
    );

    const unitPrice = item.price + addons.reduce((sum, a) => sum + a.price, 0);

    if (existingIndex > -1) {
      state.cart[existingIndex].quantity += quantity;
      state.cart[existingIndex].itemTotalPrice = state.cart[existingIndex].quantity * unitPrice;
    } else {
      state.cart.push({
        item: { ...item },
        quantity,
        addons,
        notes,
        unitPrice,
        itemTotalPrice: quantity * unitPrice
      });
    }

    playAudioChime('add');
    saveCart();
    renderMenu();
    showToast(`Added ${item.name} to your tray!`, '✨');
  }

  function updateCartQuantity(cartIndex, newQty) {
    if (newQty <= 0) {
      state.cart.splice(cartIndex, 1);
    } else {
      state.cart[cartIndex].quantity = newQty;
      state.cart[cartIndex].itemTotalPrice = newQty * state.cart[cartIndex].unitPrice;
    }
    saveCart();
    renderMenu();
  }

  function clearCart() {
    state.cart = [];
    state.appliedPromo = null;
    saveCart();
    renderMenu();
    showToast('Tray cleared', '🗑️');
  }

  /* ==========================================================================
     9. Cart UI Synchronization & Computations
     ========================================================================== */
  function updateCartUI() {
    const totalItems = state.cart.reduce((sum, line) => sum + line.quantity, 0);
    const subtotal = state.cart.reduce((sum, line) => sum + line.itemTotalPrice, 0);

    // Compute Promo Discount
    let discountAmount = 0;
    if (state.appliedPromo && subtotal > 0) {
      if (state.appliedPromo.type === 'percent') {
        discountAmount = subtotal * (state.appliedPromo.value / 100);
      } else if (state.appliedPromo.type === 'fixed') {
        discountAmount = Math.min(state.appliedPromo.value, subtotal);
      }
    }

    const finalTotal = Math.max(0, subtotal - discountAmount);

    // Header counter pills
    const pill = document.getElementById('cart-count-pill');
    const peekTotal = document.getElementById('cart-total-peek');
    const headerCount = document.getElementById('cart-header-count');

    if (pill) {
      pill.textContent = totalItems;
      pill.style.transform = 'scale(1.25)';
      setTimeout(() => pill.style.transform = 'scale(1)', 200);
    }
    if (peekTotal) peekTotal.textContent = `$${finalTotal.toFixed(2)}`;
    if (headerCount) headerCount.textContent = `(${totalItems})`;

    // Drawer Calculations
    const subtotalEl = document.getElementById('calc-subtotal');
    const discountRow = document.getElementById('discount-calc-row');
    const discountEl = document.getElementById('calc-discount');
    const totalEl = document.getElementById('calc-total');
    const checkoutBtn = document.getElementById('btn-proceed-checkout');

    if (subtotalEl) subtotalEl.textContent = `$${subtotal.toFixed(2)}`;

    if (discountRow && discountEl) {
      if (discountAmount > 0) {
        discountRow.classList.remove('hidden');
        discountEl.textContent = `-$${discountAmount.toFixed(2)}`;
      } else {
        discountRow.classList.add('hidden');
      }
    }

    if (totalEl) totalEl.textContent = `$${finalTotal.toFixed(2)}`;
    if (checkoutBtn) checkoutBtn.disabled = state.cart.length === 0;

    // Render Drawer Items List
    const drawerBody = document.getElementById('cart-drawer-body');
    if (!drawerBody) return;

    if (state.cart.length === 0) {
      drawerBody.innerHTML = `
        <div class="cart-empty-notice">
          <div class="cart-empty-emoji">🍱</div>
          <h3>Your meal tray is empty</h3>
          <p>Explore the menu above to select freshly prepared campus meals, snacks, or coffee.</p>
        </div>
      `;
    } else {
      drawerBody.innerHTML = state.cart.map((line, idx) => {
        const addonText = (line.addons && line.addons.length > 0)
          ? `<div class="cart-item-custom-tags">+ ${line.addons.map(a => a.name).join(', ')}</div>`
          : '';
        const notesText = line.notes ? `<div class="cart-item-custom-tags"><em>Note: "${line.notes}"</em></div>` : '';

        return `
          <div class="cart-item-card" data-index="${idx}">
            <img src="${line.item.image}" alt="${line.item.name}" class="cart-item-thumb" onerror="this.onerror=null; this.src='assets/burger.jpg';">
            <div class="cart-item-info">
              <span class="cart-item-name">${line.item.name}</span>
              ${addonText}
              ${notesText}
              <span class="cart-item-unit-price">$${line.itemTotalPrice.toFixed(2)}</span>
            </div>
            <div class="cart-item-controls">
              <button type="button" class="btn-remove-item" data-action="cart-remove" data-index="${idx}" aria-label="Remove item" title="Remove">✕</button>
              <div class="cart-stepper">
                <button type="button" class="btn-tray-stepper" data-action="drawer-minus" data-index="${idx}">-</button>
                <span class="tray-stepper-val">${line.quantity}</span>
                <button type="button" class="btn-tray-stepper" data-action="drawer-plus" data-index="${idx}">+</button>
              </div>
            </div>
          </div>
        `;
      }).join('');
    }
  }

  /* ==========================================================================
     10. Item Details & Customization Modal
     ========================================================================== */
  function openItemDetailsModal(itemId) {
    const item = MENU_ITEMS.find(m => m.id === itemId);
    if (!item) return;

    state.selectedModalItem = item;
    state.modalQty = 1;
    state.modalSelectedAddons = [];

    const modal = document.getElementById('item-details-modal');
    if (!modal) return;

    // Populate data
    const modalImageEl = document.getElementById('modal-item-image');
    if (modalImageEl) {
      modalImageEl.src = item.image || 'assets/burger.jpg';
      modalImageEl.alt = item.name;
      modalImageEl.onerror = function () {
        this.onerror = null;
        this.src = 'assets/burger.jpg';
      };
    }
    const modalTitleEl = document.getElementById('modal-item-title');
    if (modalTitleEl) modalTitleEl.textContent = item.name;
    const modalDescEl = document.getElementById('modal-item-desc');
    if (modalDescEl) modalDescEl.textContent = item.description;
    const modalCatEl = document.getElementById('modal-item-category');
    if (modalCatEl) modalCatEl.textContent = item.category;
    const modalRatingEl = document.getElementById('modal-item-rating');
    if (modalRatingEl) modalRatingEl.textContent = `★ ${item.rating} (${item.reviews} reviews)`;

    document.getElementById('modal-spec-calories').textContent = `${item.calories} kcal`;
    document.getElementById('modal-spec-protein').textContent = item.protein;
    document.getElementById('modal-spec-prep').textContent = item.prepTime;
    document.getElementById('modal-spec-allergens').textContent = item.allergens || 'None reported';

    // Dietary badges
    const badgesBox = document.getElementById('modal-badges-container');
    if (badgesBox) {
      badgesBox.innerHTML = (item.dietary || []).map(d => `<span class="badge-pill ${d}">${d.toUpperCase()}</span>`).join('');
    }

    // Addons
    const addonsList = document.getElementById('modal-addons-list');
    if (addonsList) {
      if (item.addons && item.addons.length > 0) {
        addonsList.innerHTML = item.addons.map(add => `
          <label class="addon-label-card">
            <div>
              <input type="checkbox" class="modal-addon-checkbox" data-id="${add.id}" data-price="${add.price}">
              <span>${add.name}</span>
            </div>
            <span class="addon-extra-price">+$${add.price.toFixed(2)}</span>
          </label>
        `).join('');
      } else {
        addonsList.innerHTML = `<p style="font-size: 0.8rem; color: var(--text-muted);">Standard chef recipe with no extra options.</p>`;
      }
    }

    // Reset notes and quantity
    const notesInput = document.getElementById('modal-chef-notes');
    if (notesInput) notesInput.value = '';

    updateModalPriceCalculation();
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }

  function updateModalPriceCalculation() {
    if (!state.selectedModalItem) return;

    const base = state.selectedModalItem.price;
    const addonsTotal = state.modalSelectedAddons.reduce((sum, a) => sum + a.price, 0);
    const lineTotal = (base + addonsTotal) * state.modalQty;

    const priceEl = document.getElementById('modal-final-price');
    const qtyEl = document.getElementById('modal-qty-display');

    if (priceEl) priceEl.textContent = `$${lineTotal.toFixed(2)}`;
    if (qtyEl) qtyEl.textContent = state.modalQty;
  }

  function closeItemDetailsModal() {
    const modal = document.getElementById('item-details-modal');
    if (modal) modal.classList.add('hidden');
    document.body.style.overflow = '';
  }

  /* ==========================================================================
     11. Checkout & Simulated Token Generation
     ========================================================================== */
  function openCheckoutModal() {
    const modal = document.getElementById('checkout-modal');
    const formView = document.getElementById('checkout-form-view');
    const successView = document.getElementById('order-success-view');
    const checkoutTotal = document.getElementById('checkout-total-val');
    const checkoutItems = document.getElementById('checkout-items-summary');

    if (!modal) return;

    // Calculate final total
    const subtotal = state.cart.reduce((sum, line) => sum + line.itemTotalPrice, 0);
    let discount = 0;
    if (state.appliedPromo) {
      discount = state.appliedPromo.type === 'percent'
        ? subtotal * (state.appliedPromo.value / 100)
        : Math.min(state.appliedPromo.value, subtotal);
    }
    const total = Math.max(0, subtotal - discount);
    const count = state.cart.reduce((sum, line) => sum + line.quantity, 0);

    if (checkoutTotal) checkoutTotal.textContent = `$${total.toFixed(2)}`;
    if (checkoutItems) checkoutItems.textContent = `${count} ${count === 1 ? 'item' : 'items'} in order`;

    // Reset views
    if (formView) formView.classList.remove('hidden');
    if (successView) successView.classList.add('hidden');

    // Close drawer
    const drawerOverlay = document.getElementById('cart-drawer-overlay');
    if (drawerOverlay) drawerOverlay.classList.add('hidden');

    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }

  function handleOrderFormSubmit(e) {
    e.preventDefault();

    const name = document.getElementById('student-name')?.value?.trim() || 'Student';
    const roll = document.getElementById('student-roll')?.value?.trim() || 'CAMPUS';
    const counterSelect = document.getElementById('pickup-location-select');
    const counterText = counterSelect && counterSelect.selectedIndex >= 0 ? counterSelect.options[counterSelect.selectedIndex].text : 'Counter 1';
    const paymentMethodEl = document.querySelector('input[name="payment-method"]:checked');
    const strongEl = paymentMethodEl?.closest('.payment-option')?.querySelector('strong');
    const paymentLabel = strongEl ? strongEl.textContent.trim() : 'Student Campus Card';

    // Generate random campus token
    const randomId = Math.floor(100 + Math.random() * 900);
    const tokenId = `#UB-${randomId}`;

    // Estimated pickup time: current time + 8 mins
    const now = new Date();
    now.setMinutes(now.getMinutes() + 8);
    const readyTimeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Populate Success Ticket
    const tokenIdEl = document.getElementById('success-token-id');
    if (tokenIdEl) tokenIdEl.textContent = tokenId;
    const counterEl = document.getElementById('success-counter-assigned');
    if (counterEl) counterEl.textContent = `Pickup at: ${counterText}`;
    const nameEl = document.getElementById('ticket-student-name');
    if (nameEl) nameEl.textContent = name;
    const rollEl = document.getElementById('ticket-student-roll');
    if (rollEl) rollEl.textContent = roll;
    const timeEl = document.getElementById('ticket-ready-time');
    if (timeEl) timeEl.textContent = `${readyTimeString} (~8 mins)`;
    const payEl = document.getElementById('ticket-payment-type');
    if (payEl) payEl.textContent = paymentLabel;

    // Items list on ticket
    const ticketItemsList = document.getElementById('ticket-items-list');
    if (ticketItemsList) {
      ticketItemsList.innerHTML = state.cart.map(line => `
        <div class="ticket-item-row">
          <span>${line.quantity}x ${line.item.name}</span>
          <span>$${line.itemTotalPrice.toFixed(2)}</span>
        </div>
      `).join('');
    }

    const calcTotalEl = document.getElementById('calc-total');
    const finalTotal = calcTotalEl ? calcTotalEl.textContent : '$0.00';
    const ticketTotalEl = document.getElementById('ticket-total-price');
    if (ticketTotalEl) ticketTotalEl.textContent = finalTotal;

    // Switch views
    const formView = document.getElementById('checkout-form-view');
    if (formView) formView.classList.add('hidden');
    const successView = document.getElementById('order-success-view');
    if (successView) successView.classList.remove('hidden');

    playAudioChime('success');
    showToast(`Order Placed! Token: ${tokenId}`, '🎉');

    // Clear cart after order placement and synchronize menu cards
    state.cart = [];
    state.appliedPromo = null;
    saveCart();
    renderMenu();
  }

  /* ==========================================================================
     12. Category Badges Count Sync
     ========================================================================== */
  function updateCategoryCounts() {
    const counts = {
      all: MENU_ITEMS.length,
      burgers: 0,
      mains: 0,
      pizza: 0,
      bowls: 0,
      breakfast: 0,
      beverages: 0
    };

    MENU_ITEMS.forEach(m => {
      if (counts[m.category] !== undefined) counts[m.category]++;
    });

    Object.keys(counts).forEach(cat => {
      const el = document.getElementById(`count-${cat}`);
      if (el) el.textContent = counts[cat];
    });

    // Update Favorites Badge in Header
    const favBadge = document.getElementById('fav-count-badge');
    if (favBadge) {
      favBadge.textContent = state.favorites.size;
      if (state.favorites.size > 0) {
        favBadge.classList.remove('count-zero');
      } else {
        favBadge.classList.add('count-zero');
      }
    }
  }

  /* ==========================================================================
     13. Setup Event Listeners
     ========================================================================== */
  function initEventListeners() {
    // Search input
    const searchInput = document.getElementById('menu-search-input');
    const searchClear = document.getElementById('search-clear-btn');

    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        state.searchQuery = e.target.value;
        if (searchClear) {
          if (state.searchQuery.length > 0) {
            searchClear.classList.remove('hidden');
          } else {
            searchClear.classList.add('hidden');
          }
        }
        renderMenu();
      });

      // Keyboard shortcut '/'
      window.addEventListener('keydown', (e) => {
        if (e.key === '/' && document.activeElement !== searchInput && !document.activeElement.matches('input, textarea')) {
          e.preventDefault();
          searchInput.focus();
        }
      });
    }

    if (searchClear) {
      searchClear.addEventListener('click', () => {
        searchInput.value = '';
        state.searchQuery = '';
        searchClear.classList.add('hidden');
        renderMenu();
        searchInput.focus();
      });
    }

    // Category Tabs
    const tabsContainer = document.getElementById('category-tabs');
    if (tabsContainer) {
      tabsContainer.addEventListener('click', (e) => {
        const tab = e.target.closest('.category-tab');
        if (!tab) return;

        tabsContainer.querySelectorAll('.category-tab').forEach(t => {
          t.classList.remove('active');
          t.setAttribute('aria-selected', 'false');
        });

        tab.classList.add('active');
        tab.setAttribute('aria-selected', 'true');
        state.activeCategory = tab.dataset.category;
        renderMenu();
      });
    }

    // Dietary Filter Chips
    const dietaryList = document.getElementById('dietary-pills-list');
    if (dietaryList) {
      dietaryList.addEventListener('click', (e) => {
        const chip = e.target.closest('.diet-chip');
        if (!chip) return;

        const diet = chip.dataset.diet;
        if (state.activeDietary.has(diet)) {
          state.activeDietary.delete(diet);
          chip.classList.remove('active');
        } else {
          state.activeDietary.add(diet);
          chip.classList.add('active');
        }
        renderMenu();
      });
    }

    // Reset Filters button
    const resetFiltersBtn = document.getElementById('btn-reset-filters');
    const emptyResetBtn = document.getElementById('btn-empty-reset');

    function resetAllFilters() {
      state.searchQuery = '';
      state.activeCategory = 'all';
      state.activeDietary.clear();

      if (searchInput) searchInput.value = '';
      if (searchClear) searchClear.classList.add('hidden');

      if (tabsContainer) {
        tabsContainer.querySelectorAll('.category-tab').forEach(t => {
          t.classList.toggle('active', t.dataset.category === 'all');
          t.setAttribute('aria-selected', t.dataset.category === 'all' ? 'true' : 'false');
        });
      }

      if (dietaryList) {
        dietaryList.querySelectorAll('.diet-chip').forEach(c => c.classList.remove('active'));
      }

      renderMenu();
    }

    if (resetFiltersBtn) resetFiltersBtn.addEventListener('click', resetAllFilters);
    if (emptyResetBtn) emptyResetBtn.addEventListener('click', resetAllFilters);

    // Sorting Dropdown
    const sortSelect = document.getElementById('sort-select');
    if (sortSelect) {
      sortSelect.addEventListener('change', (e) => {
        state.currentSort = e.target.value;
        renderMenu();
      });
    }

    // View Mode Toggle (Grid vs List)
    const gridBtn = document.getElementById('view-grid-btn');
    const listBtn = document.getElementById('view-list-btn');
    const menuGrid = document.getElementById('menu-grid');

    if (gridBtn && listBtn && menuGrid) {
      gridBtn.addEventListener('click', () => {
        state.viewMode = 'grid';
        gridBtn.classList.add('active');
        listBtn.classList.remove('active');
        menuGrid.className = 'menu-grid view-mode-grid';
      });

      listBtn.addEventListener('click', () => {
        state.viewMode = 'list';
        listBtn.classList.add('active');
        gridBtn.classList.remove('active');
        menuGrid.className = 'menu-grid view-mode-list';
      });
    }

    // Menu Grid Card Events (Delegated)
    if (menuGrid) {
      menuGrid.addEventListener('click', (e) => {
        // Favorite toggle
        const favBtn = e.target.closest('.btn-card-fav');
        if (favBtn) {
          const itemId = favBtn.dataset.id;
          if (state.favorites.has(itemId)) {
            state.favorites.delete(itemId);
            favBtn.classList.remove('is-favorite');
            showToast('Removed from favorites', '🤍');
          } else {
            state.favorites.add(itemId);
            favBtn.classList.add('is-favorite');
            showToast('Added to campus favorites!', '❤️');
          }
          safeSetStorage('unibites_favorites', [...state.favorites]);
          updateCategoryCounts();
          return;
        }

        // Details modal button
        const detailsBtn = e.target.closest('.btn-card-details');
        if (detailsBtn) {
          openItemDetailsModal(detailsBtn.dataset.id);
          return;
        }

        // Add to Cart button
        const addBtn = e.target.closest('.btn-card-add');
        if (addBtn) {
          addToCart(addBtn.dataset.id, 1);
          return;
        }

        // Card Quantity Steppers
        const stepperBtn = e.target.closest('.btn-card-stepper');
        if (stepperBtn) {
          const action = stepperBtn.dataset.action;
          const itemId = stepperBtn.dataset.id;
          const lineIndex = state.cart.findIndex(l => l.item.id === itemId);

          if (lineIndex > -1) {
            if (action === 'card-plus') {
              updateCartQuantity(lineIndex, state.cart[lineIndex].quantity + 1);
            } else if (action === 'card-minus') {
              updateCartQuantity(lineIndex, state.cart[lineIndex].quantity - 1);
            }
          }
        }
      });
    }

    // Quick Add Special Button in Hero
    const heroSpecialAdd = document.getElementById('btn-quick-add-special');
    if (heroSpecialAdd) {
      heroSpecialAdd.addEventListener('click', () => {
        addToCart('item-1', 1);
      });
    }

    // Drawer Open / Close
    const openCartBtn = document.getElementById('btn-open-cart');
    const closeCartBtn = document.getElementById('btn-close-cart');
    const cartOverlay = document.getElementById('cart-drawer-overlay');

    if (openCartBtn && cartOverlay) {
      openCartBtn.addEventListener('click', () => {
        cartOverlay.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
      });
    }

    if (closeCartBtn && cartOverlay) {
      closeCartBtn.addEventListener('click', () => {
        cartOverlay.classList.add('hidden');
        document.body.style.overflow = '';
      });
    }

    if (cartOverlay) {
      cartOverlay.addEventListener('click', (e) => {
        if (e.target === cartOverlay) {
          cartOverlay.classList.add('hidden');
          document.body.style.overflow = '';
        }
      });
    }

    // Cart Drawer Body Actions (Delegated)
    const drawerBody = document.getElementById('cart-drawer-body');
    if (drawerBody) {
      drawerBody.addEventListener('click', (e) => {
        const removeBtn = e.target.closest('.btn-remove-item');
        if (removeBtn) {
          const idx = parseInt(removeBtn.dataset.index, 10);
          updateCartQuantity(idx, 0);
          return;
        }

        const stepBtn = e.target.closest('.btn-tray-stepper');
        if (stepBtn) {
          const action = stepBtn.dataset.action;
          const idx = parseInt(stepBtn.dataset.index, 10);
          if (action === 'drawer-plus') {
            updateCartQuantity(idx, state.cart[idx].quantity + 1);
          } else if (action === 'drawer-minus') {
            updateCartQuantity(idx, state.cart[idx].quantity - 1);
          }
        }
      });
    }

    // Clear Tray Button
    const clearTrayBtn = document.getElementById('btn-clear-cart');
    if (clearTrayBtn) clearTrayBtn.addEventListener('click', clearCart);

    // Promo Code Application
    const promoInput = document.getElementById('promo-input');
    const promoBtn = document.getElementById('btn-apply-promo');
    const promoMsg = document.getElementById('promo-status-msg');

    if (promoInput && promoMsg) {
      promoInput.addEventListener('input', () => {
        promoMsg.textContent = '';
        promoMsg.className = 'promo-status-msg';
      });
    }

    if (promoBtn && promoInput && promoMsg) {
      promoBtn.addEventListener('click', () => {
        const code = promoInput.value.trim().toUpperCase();
        if (!code) {
          promoMsg.className = 'promo-status-msg error';
          promoMsg.textContent = 'Please enter a coupon code.';
          return;
        }

        if (PROMO_CODES[code]) {
          state.appliedPromo = { code, ...PROMO_CODES[code] };
          promoMsg.className = 'promo-status-msg success';
          promoMsg.textContent = `Applied: ${PROMO_CODES[code].label}!`;
          playAudioChime('add');
          updateCartUI();
        } else {
          promoMsg.className = 'promo-status-msg error';
          promoMsg.textContent = 'Invalid code. Try "STUDENT15"';
        }
      });
    }

    // Click on header announcement promo code to auto-copy & auto-apply
    const copyPromo = document.getElementById('header-promo-copy');
    if (copyPromo && promoInput) {
      copyPromo.addEventListener('click', () => {
        promoInput.value = 'STUDENT15';
        if (promoMsg) {
          promoMsg.textContent = '';
          promoMsg.className = 'promo-status-msg';
        }
        if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
          navigator.clipboard.writeText('STUDENT15').catch(() => {});
        }
        showToast('Code STUDENT15 copied & ready to apply in cart!', '🎟️');
      });
    }

    // Details Modal Events
    const closeDetailModalBtn = document.getElementById('btn-close-detail-modal');
    const detailModal = document.getElementById('item-details-modal');

    if (closeDetailModalBtn) closeDetailModalBtn.addEventListener('click', closeItemDetailsModal);
    if (detailModal) {
      detailModal.addEventListener('click', (e) => {
        if (e.target === detailModal) closeItemDetailsModal();
      });
    }

    // Details Modal Addons changes
    const addonsList = document.getElementById('modal-addons-list');
    if (addonsList) {
      addonsList.addEventListener('change', (e) => {
        if (e.target.classList.contains('modal-addon-checkbox')) {
          const addonId = e.target.dataset.id;
          const addonObj = state.selectedModalItem?.addons?.find(a => a.id === addonId);
          if (!addonObj) return;

          if (e.target.checked) {
            state.modalSelectedAddons.push(addonObj);
          } else {
            state.modalSelectedAddons = state.modalSelectedAddons.filter(a => a.id !== addonId);
          }
          updateModalPriceCalculation();
        }
      });
    }

    // Modal Quantity Controls
    const modalMinus = document.getElementById('btn-modal-qty-minus');
    const modalPlus = document.getElementById('btn-modal-qty-plus');

    if (modalMinus) {
      modalMinus.addEventListener('click', () => {
        if (state.modalQty > 1) {
          state.modalQty--;
          updateModalPriceCalculation();
        }
      });
    }

    if (modalPlus) {
      modalPlus.addEventListener('click', () => {
        state.modalQty++;
        updateModalPriceCalculation();
      });
    }

    // Add to Tray from Modal
    const modalAddBtn = document.getElementById('btn-modal-add-to-tray');
    if (modalAddBtn) {
      modalAddBtn.addEventListener('click', () => {
        if (!state.selectedModalItem) return;
        const notes = document.getElementById('modal-chef-notes')?.value.trim() || '';
        addToCart(state.selectedModalItem.id, state.modalQty, [...state.modalSelectedAddons], notes);
        closeItemDetailsModal();
      });
    }

    // Checkout Modal
    const proceedCheckoutBtn = document.getElementById('btn-proceed-checkout');
    const closeCheckoutModalBtn = document.getElementById('btn-close-checkout-modal');
    const checkoutModal = document.getElementById('checkout-modal');
    const orderForm = document.getElementById('campus-order-form');
    const newOrderBtn = document.getElementById('btn-new-order');
    const printReceiptBtn = document.getElementById('btn-print-receipt');

    if (proceedCheckoutBtn) proceedCheckoutBtn.addEventListener('click', openCheckoutModal);
    if (closeCheckoutModalBtn && checkoutModal) {
      closeCheckoutModalBtn.addEventListener('click', () => {
        checkoutModal.classList.add('hidden');
        document.body.style.overflow = '';
      });
    }
    if (checkoutModal) {
      checkoutModal.addEventListener('click', (e) => {
        if (e.target === checkoutModal) {
          checkoutModal.classList.add('hidden');
          document.body.style.overflow = '';
        }
      });
    }

    if (orderForm) orderForm.addEventListener('submit', handleOrderFormSubmit);

    if (newOrderBtn && checkoutModal) {
      newOrderBtn.addEventListener('click', () => {
        checkoutModal.classList.add('hidden');
        document.body.style.overflow = '';
        renderMenu();
      });
    }

    if (printReceiptBtn) {
      printReceiptBtn.addEventListener('click', () => {
        window.print();
      });
    }

    // Hours and Info Modal
    const hoursBtn = document.getElementById('btn-hours-info');
    const hoursModal = document.getElementById('hours-info-modal');
    const closeHoursBtn = document.getElementById('btn-close-hours-modal');
    const dismissHoursBtn = document.getElementById('btn-dismiss-hours');

    function openHours() {
      if (hoursModal) {
        hoursModal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
      }
    }

    function closeHours() {
      if (hoursModal) {
        hoursModal.classList.add('hidden');
        document.body.style.overflow = '';
      }
    }

    if (hoursBtn) hoursBtn.addEventListener('click', openHours);
    if (closeHoursBtn) closeHoursBtn.addEventListener('click', closeHours);
    if (dismissHoursBtn) dismissHoursBtn.addEventListener('click', closeHours);
    if (hoursModal) {
      hoursModal.addEventListener('click', (e) => {
        if (e.target === hoursModal) closeHours();
      });
    }

    // Favorites Quick Filter in Header
    const showFavsBtn = document.getElementById('btn-show-favorites');
    if (showFavsBtn) {
      showFavsBtn.addEventListener('click', () => {
        if (state.activeCategory === 'favorites') {
          state.activeCategory = 'all';
          showFavsBtn.classList.remove('active');
        } else {
          state.activeCategory = 'favorites';
          showFavsBtn.classList.add('active');
        }

        // deselect tabs
        if (tabsContainer) {
          tabsContainer.querySelectorAll('.category-tab').forEach(t => {
            t.classList.toggle('active', t.dataset.category === state.activeCategory);
          });
        }

        renderMenu();
      });
    }

    // Dark / Light Theme Toggle
    const themeBtn = document.getElementById('theme-toggle-btn');
    const savedTheme = (function () {
      try {
        return localStorage.getItem('unibites_theme') || 
          (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
      } catch (e) {
        return 'light';
      }
    })();

    document.documentElement.setAttribute('data-theme', savedTheme);
    state.theme = savedTheme;

    if (themeBtn) {
      themeBtn.addEventListener('click', () => {
        const nextTheme = state.theme === 'dark' ? 'light' : 'dark';
        state.theme = nextTheme;
        document.documentElement.setAttribute('data-theme', nextTheme);
        safeSetStorage('unibites_theme', nextTheme);
        showToast(`Switched to ${nextTheme} mode`, nextTheme === 'dark' ? '🌙' : '☀️');
      });
    }
  }

  /* ==========================================================================
     14. Application Initialization
     ========================================================================== */
  function init() {
    initEventListeners();
    renderMenu();
    updateCartUI();
  }

  // Run on DOM Ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
